import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { useGetTurnstileConfig, useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Logo } from "@/components/Logo";
import { Turnstile } from "@/components/turnstile";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export default function LoginPage() {
  const [, navigate] = useLocation();
  const qc = useQueryClient();
  const cfg = useGetTurnstileConfig();
  const login = useLogin();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");

  useEffect(() => {
    document.title = "Sign in — GScripts AI";
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Enter your email and password.");
      return;
    }
    if (!token) {
      toast.error("Please complete the verification challenge.");
      return;
    }
    try {
      await login.mutateAsync({ data: { email, password, turnstileToken: token } });
      await qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
      navigate("/app/chat");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Login failed";
      toast.error(msg.replace(/^HTTP \d+ \w+:?\s*/, ""));
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="border-b border-border/40 px-6 py-4">
        <Logo />
      </header>
      <main className="flex flex-1 items-center justify-center p-6">
        <Card className="w-full max-w-md border-border/60 bg-card/60 p-8 shadow-2xl shadow-black/40 ring-1 ring-white/5">
          <div className="mb-7">
            <h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Sign in to your GScripts AI workspace.
            </p>
          </div>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="input-email"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="input-password"
              />
            </div>
            <div className="pt-1">
              {cfg.data?.siteKey ? (
                <Turnstile siteKey={cfg.data.siteKey} onToken={setToken} />
              ) : (
                <div className="h-[65px] rounded-md border border-dashed border-border/60 px-3 py-4 text-xs text-muted-foreground">
                  Loading verification…
                </div>
              )}
            </div>
            <Button
              type="submit"
              className="w-full gap-2"
              disabled={login.isPending}
              data-testid="button-submit-login"
            >
              {login.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Sign in
            </Button>
          </form>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            New here?{" "}
            <Link href="/signup" className="text-primary hover:underline" data-testid="link-go-signup">
              Create an account
            </Link>
          </p>
        </Card>
      </main>
    </div>
  );
}
