import { useEffect, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import {
  useGetMe,
  useListConversations,
  useCreateConversation,
  useDeleteConversation,
  useLogout,
  getListConversationsQueryKey,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  MessageSquare,
  Folder,
  Bot,
  Plus,
  LogOut,
  Trash2,
  Loader2,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [, navigate] = useLocation();
  const me = useGetMe();
  const qc = useQueryClient();
  const logout = useLogout();

  useEffect(() => {
    if (!me.isLoading && !me.data?.user) {
      navigate("/login");
    }
  }, [me.isLoading, me.data, navigate]);

  if (me.isLoading || !me.data?.user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const user = me.data.user;

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <Sidebar
        userName={user.displayName}
        userEmail={user.email}
        isOwner={user.isOwner}
        onLogout={async () => {
          try {
            await logout.mutateAsync();
          } catch {
            // ignore
          }
          await qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
          navigate("/login");
        }}
      />
      <main className="flex-1 overflow-hidden">{children}</main>
    </div>
  );
}

function Sidebar({
  userName,
  userEmail,
  isOwner,
  onLogout,
}: {
  userName: string;
  userEmail: string;
  isOwner: boolean;
  onLogout: () => void;
}) {
  const conversations = useListConversations();
  const create = useCreateConversation();
  const del = useDeleteConversation();
  const qc = useQueryClient();
  const [, navigate] = useLocation();
  const [matchChat, paramsChat] = useRoute("/app/chat/:id");
  const [matchChatRoot] = useRoute("/app/chat");
  const [matchWorkspace] = useRoute("/app/workspace");
  const [matchBots] = useRoute("/app/bots");
  const activeId = matchChat ? paramsChat?.id : null;
  const [hovering, setHovering] = useState<string | null>(null);

  async function handleNewChat() {
    try {
      const res = await create.mutateAsync({ data: {} });
      await qc.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      navigate(`/app/chat/${res.id}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(msg);
    }
  }

  async function handleDelete(id: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    try {
      await del.mutateAsync({ id });
      await qc.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      if (activeId === id) navigate("/app/chat");
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <aside className="flex w-72 flex-none flex-col border-r border-border/60 bg-card/30">
      <div className="flex items-center justify-between px-4 py-4">
        <Logo to="/app/chat" />
        {isOwner && (
          <span
            className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary"
            data-testid="badge-owner"
          >
            <Sparkles className="h-3 w-3" />
            Owner
          </span>
        )}
      </div>

      <nav className="space-y-0.5 px-3">
        <NavItem
          to="/app/chat"
          icon={MessageSquare}
          label="Chat"
          active={Boolean(matchChatRoot || matchChat)}
        />
        <NavItem
          to="/app/workspace"
          icon={Folder}
          label="Workspace"
          active={matchWorkspace}
        />
        <NavItem to="/app/bots" icon={Bot} label="Bots" active={matchBots} />
      </nav>

      <div className="mt-6 flex items-center justify-between px-4">
        <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          Conversations
        </span>
        <button
          className="rounded-md p-1 text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
          onClick={handleNewChat}
          disabled={create.isPending}
          data-testid="button-new-chat"
          aria-label="New chat"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="mt-2 flex-1 overflow-y-auto px-2 pb-2">
        {conversations.isLoading ? (
          <div className="px-3 py-2 text-xs text-muted-foreground">Loading…</div>
        ) : (conversations.data?.length ?? 0) === 0 ? (
          <div className="px-3 py-2 text-xs text-muted-foreground">No conversations yet.</div>
        ) : (
          <ul className="space-y-0.5">
            {conversations.data?.map((c) => {
              const isActive = activeId === c.id;
              return (
                <li
                  key={c.id}
                  onMouseEnter={() => setHovering(c.id)}
                  onMouseLeave={() => setHovering((h) => (h === c.id ? null : h))}
                >
                  <div
                    className={
                      "group flex items-center gap-2 rounded-md px-3 py-1.5 text-sm transition-colors " +
                      (isActive
                        ? "bg-secondary text-foreground"
                        : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground")
                    }
                  >
                    <Link
                      href={`/app/chat/${c.id}`}
                      className="flex min-w-0 flex-1 items-center gap-2"
                      data-testid={`link-conversation-${c.id}`}
                    >
                      <MessageSquare className="h-3.5 w-3.5 flex-none opacity-70" />
                      <span className="flex-1 truncate">{c.title}</span>
                    </Link>
                    {(hovering === c.id || isActive) && (
                      <button
                        className="rounded p-0.5 text-muted-foreground hover:bg-destructive/20 hover:text-destructive"
                        onClick={(e) => handleDelete(c.id, e)}
                        aria-label="Delete conversation"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="border-t border-border/60 p-3">
        <div className="flex items-center gap-3 rounded-md bg-secondary/30 px-3 py-2">
          <div className="flex h-7 w-7 flex-none items-center justify-center rounded-full bg-primary/20 text-xs font-semibold text-primary">
            {userName[0]?.toUpperCase() || "?"}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium" data-testid="text-user-name">
              {userName}
            </div>
            <div className="truncate text-[11px] text-muted-foreground">{userEmail}</div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-foreground"
            onClick={onLogout}
            aria-label="Sign out"
            data-testid="button-logout"
          >
            <LogOut className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </aside>
  );
}

function NavItem({
  to,
  icon: Icon,
  label,
  active,
}: {
  to: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active?: boolean;
}) {
  return (
    <Link
      href={to}
      data-testid={`link-nav-${label.toLowerCase()}`}
      className={
        "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors " +
        (active
          ? "bg-secondary text-foreground"
          : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground")
      }
    >
      <Icon className="h-4 w-4" />
      {label}
    </Link>
  );
}
