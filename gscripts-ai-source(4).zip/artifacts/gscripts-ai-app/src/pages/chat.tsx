import { useEffect, useRef, useState, useMemo, useCallback } from "react";
import { useLocation, useRoute } from "wouter";
import {
  useGetConversation,
  useCreateConversation,
  useUploadFile,
  getListConversationsQueryKey,
  getGetConversationQueryKey,
  type AttachmentDto,
  type MessageDto,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { streamMessage, type StreamEvent } from "@/lib/streaming";
import { RichText } from "@/components/CodeBlock";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  ArrowUp,
  ChevronDown,
  ChevronRight,
  Loader2,
  Paperclip,
  X,
  FileText,
  Sparkles,
  Brain,
  Download,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { isTextLikeMime, formatBytes } from "@/lib/format";
import { GeneratedFiles } from "@/components/GeneratedFiles";

const BASE = (import.meta.env.BASE_URL || "/").replace(/\/$/, "");

type LiveToolCall = {
  id: string;
  name: string;
  input: Record<string, unknown>;
  status: "running" | "ok" | "error";
  summary?: string;
};

type LocalMessage = MessageDto & {
  pending?: boolean;
  liveText?: string;
  liveThinking?: string;
  liveFileIds?: string[];
  liveTools?: LiveToolCall[];
};

type LocalAttachment = {
  fileId: string;
  name: string;
  size: number;
  mimeType: string;
};

export default function ChatPage() {
  const [, paramsExisting] = useRoute("/app/chat/:id");
  const [matchRoot] = useRoute("/app/chat");
  const [, navigate] = useLocation();
  const qc = useQueryClient();

  const id = paramsExisting?.id ?? null;

  if (!id && matchRoot) return <ChatEmpty />;
  if (!id) return null;

  return <ChatView key={id} id={id} navigate={navigate} qc={qc} />;
}

function ChatEmpty() {
  const create = useCreateConversation();
  const qc = useQueryClient();
  const [, navigate] = useLocation();

  async function start() {
    const res = await create.mutateAsync({ data: {} });
    await qc.invalidateQueries({ queryKey: getListConversationsQueryKey() });
    navigate(`/app/chat/${res.id}`);
  }

  const suggestions = [
    "Write a Python script that scrapes a JSON API on a 30-second loop with retry & jitter.",
    "Generate a Discord bot scaffold with slash commands and a dynamic prefix loader.",
    "Build a Roblox Luau anti-AFK script with a togglable ScreenGui.",
    "Take this minified JS and produce a readable, fully renamed deobfuscation.",
  ];

  return (
    <div className="flex h-full flex-col items-center justify-center px-6">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
        <Sparkles className="h-5 w-5" />
      </div>
      <h2 className="mt-4 text-2xl font-semibold tracking-tight">What are we shipping?</h2>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Start a chat. GScripts thinks first, then writes the file.
      </p>
      <div className="mt-8 grid w-full max-w-2xl gap-2 md:grid-cols-2">
        {suggestions.map((s) => (
          <button
            key={s}
            onClick={start}
            className="rounded-md border border-border/60 bg-card/40 px-3 py-2.5 text-left text-sm text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
            data-testid="button-suggestion"
          >
            {s}
          </button>
        ))}
      </div>
      <Button onClick={start} className="mt-6 gap-2" data-testid="button-start-chat">
        <Sparkles className="h-4 w-4" />
        New chat
      </Button>
    </div>
  );
}

function ChatView({
  id,
  navigate,
  qc,
}: {
  id: string;
  navigate: (path: string) => void;
  qc: ReturnType<typeof useQueryClient>;
}) {
  const conv = useGetConversation(id);
  const upload = useUploadFile();
  const [draft, setDraft] = useState("");
  const [attachments, setAttachments] = useState<LocalAttachment[]>([]);
  const [pendingMsg, setPendingMsg] = useState<LocalMessage | null>(null);
  const [streaming, setStreaming] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  const allMessages: LocalMessage[] = useMemo(() => {
    const base = conv.data?.messages ?? [];
    return pendingMsg ? [...base, pendingMsg] : base;
  }, [conv.data, pendingMsg]);

  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, []);

  useEffect(() => {
    if (autoScroll) scrollToBottom();
  }, [allMessages, autoScroll, scrollToBottom]);

  function handleScroll() {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    setAutoScroll(atBottom);
  }

  async function handleAttachFiles(files: FileList | File[]) {
    const arr = Array.from(files);
    for (const f of arr) {
      if (f.size > 10 * 1024 * 1024) {
        toast.error(`${f.name} is over 10MB and was skipped.`);
        continue;
      }
      try {
        const isText = isTextLikeMime(f.type || "text/plain");
        let content: string | null = null;
        let dataB64: string | null = null;
        if (isText) {
          content = await f.text();
        } else {
          const buf = await f.arrayBuffer();
          dataB64 = arrayBufferToBase64(buf);
        }
        const res = await upload.mutateAsync({
          data: {
            name: f.name,
            mimeType: f.type || "application/octet-stream",
            size: f.size,
            folder: "/uploads",
            content,
            dataB64,
            conversationId: id,
          },
        });
        setAttachments((s) => [
          ...s,
          { fileId: res.id, name: res.name, size: res.size, mimeType: res.mimeType },
        ]);
      } catch (err) {
        toast.error(`Failed to upload ${f.name}`);
      }
    }
  }

  async function send() {
    const content = draft.trim();
    if (!content || streaming) return;
    setDraft("");
    const localAtts: AttachmentDto[] = attachments.map((a) => ({
      fileId: a.fileId,
      name: a.name,
      mimeType: a.mimeType,
      size: a.size,
    }));
    const userMsg: LocalMessage = {
      id: `tmp-user-${Date.now()}`,
      role: "user",
      content,
      thinking: null,
      attachments: localAtts,
      generatedFileIds: [],
      createdAt: new Date().toISOString(),
    };
    const fileIdsForReq = attachments.map((a) => a.fileId);
    setAttachments([]);

    qc.setQueryData(
      getGetConversationQueryKey(id),
      (old: typeof conv.data | undefined) => {
        if (!old) return old;
        return { ...old, messages: [...old.messages, userMsg] };
      },
    );

    setPendingMsg({
      id: "tmp-assist",
      role: "assistant",
      content: "",
      thinking: null,
      attachments: [],
      generatedFileIds: [],
      createdAt: new Date().toISOString(),
      pending: true,
      liveText: "",
      liveThinking: "",
      liveFileIds: [],
      liveTools: [],
    });
    setStreaming(true);
    setAutoScroll(true);

    let liveText = "";
    let liveThinking = "";
    let liveFileIds: string[] = [];
    let liveTools: LiveToolCall[] = [];

    try {
      await streamMessage(
        id,
        { content, attachmentFileIds: fileIdsForReq },
        BASE,
        (e: StreamEvent) => {
          if (e.type === "delta") {
            liveText += e.content;
          } else if (e.type === "thinking") {
            liveThinking += e.content;
          } else if (e.type === "files") {
            liveFileIds = e.fileIds;
          } else if (e.type === "tool_use") {
            liveTools = [
              ...liveTools,
              {
                id: `t-${liveTools.length}-${e.name}`,
                name: e.name,
                input: e.input,
                status: "running",
              },
            ];
          } else if (e.type === "tool_result") {
            // Mark the most recent running tool with the matching name as done.
            const idx = [...liveTools].reverse().findIndex(
              (t) => t.name === e.name && t.status === "running",
            );
            if (idx !== -1) {
              const realIdx = liveTools.length - 1 - idx;
              const next = liveTools.slice();
              next[realIdx] = {
                ...next[realIdx],
                status: e.ok ? "ok" : "error",
                summary: e.summary,
              };
              liveTools = next;
            }
          } else if (e.type === "error") {
            toast.error(e.message);
          }
          setPendingMsg({
            id: "tmp-assist",
            role: "assistant",
            content: "",
            thinking: null,
            attachments: [],
            generatedFileIds: [],
            createdAt: new Date().toISOString(),
            pending: true,
            liveText,
            liveThinking,
            liveFileIds,
            liveTools,
          });
        },
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Stream failed";
      toast.error(msg);
    } finally {
      setStreaming(false);
      setPendingMsg(null);
      await qc.invalidateQueries({ queryKey: getGetConversationQueryKey(id) });
      await qc.invalidateQueries({ queryKey: getListConversationsQueryKey() });
    }
  }

  return (
    <div
      className="flex h-full flex-col"
      onDragOver={(e) => {
        e.preventDefault();
      }}
      onDrop={(e) => {
        e.preventDefault();
        if (e.dataTransfer.files?.length) handleAttachFiles(e.dataTransfer.files);
      }}
    >
      <header className="flex items-center justify-between border-b border-border/60 bg-card/30 px-6 py-3">
        <div className="min-w-0">
          <h1 className="truncate text-sm font-medium" data-testid="text-conversation-title">
            {conv.data?.conversation.title || "New chat"}
          </h1>
        </div>
      </header>

      <div ref={scrollRef} onScroll={handleScroll} className="flex-1 overflow-y-auto">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8 md:px-6">
          {conv.isLoading && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading conversation…
            </div>
          )}
          <AnimatePresence initial={false}>
            {allMessages.map((m) => (
              <MessageBubble key={m.id} m={m} />
            ))}
          </AnimatePresence>
        </div>
      </div>

      <footer className="border-t border-border/60 bg-card/30 px-4 pb-4 pt-3">
        <div className="mx-auto max-w-3xl">
          {attachments.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-1.5">
              {attachments.map((a) => (
                <div
                  key={a.fileId}
                  className="flex items-center gap-1.5 rounded-md border border-border/60 bg-secondary/40 px-2 py-1 text-xs"
                >
                  <FileText className="h-3 w-3 text-muted-foreground" />
                  <span className="max-w-[180px] truncate">{a.name}</span>
                  <span className="text-muted-foreground">{formatBytes(a.size)}</span>
                  <button
                    onClick={() =>
                      setAttachments((s) => s.filter((x) => x.fileId !== a.fileId))
                    }
                    className="rounded p-0.5 text-muted-foreground hover:bg-destructive/20 hover:text-destructive"
                    aria-label="Remove attachment"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="rounded-xl border border-border/60 bg-card/60 p-2 shadow-lg shadow-black/30 ring-1 ring-white/5">
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              onPaste={(e) => {
                const items = e.clipboardData?.items;
                if (!items) return;
                const filesFromClip: File[] = [];
                for (let i = 0; i < items.length; i++) {
                  const it = items[i];
                  if (it.kind === "file") {
                    const f = it.getAsFile();
                    if (f) {
                      // Pasted screenshots often have empty name "image.png"
                      const named =
                        f.name && f.name !== "image.png"
                          ? f
                          : new File([f], `pasted-${Date.now()}.png`, { type: f.type || "image/png" });
                      filesFromClip.push(named);
                    }
                  }
                }
                if (filesFromClip.length > 0) {
                  e.preventDefault();
                  handleAttachFiles(filesFromClip);
                  toast.success(
                    filesFromClip.length === 1
                      ? "Pasted image attached"
                      : `${filesFromClip.length} pasted files attached`,
                  );
                }
              }}
              placeholder="Ask GScripts to build something. Paste images with Ctrl+V, attach files, or drag them in."
              className="min-h-[60px] resize-none border-0 bg-transparent px-3 py-2 text-[14.5px] focus-visible:ring-0"
              data-testid="input-chat-message"
            />
            <div className="flex items-center justify-between px-2 pb-1 pt-1">
              <label className="flex cursor-pointer items-center gap-1.5 rounded-md px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground">
                <Paperclip className="h-3.5 w-3.5" />
                Attach
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files) handleAttachFiles(e.target.files);
                    e.currentTarget.value = "";
                  }}
                  data-testid="input-attach"
                />
              </label>
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                <span>Enter to send · Shift+Enter newline</span>
                <Button
                  size="sm"
                  className="h-7 w-7 p-0"
                  onClick={send}
                  disabled={!draft.trim() || streaming}
                  data-testid="button-send"
                  aria-label="Send"
                >
                  {streaming ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <ArrowUp className="h-3.5 w-3.5" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function MessageBubble({ m }: { m: LocalMessage }) {
  const isUser = m.role === "user";
  const text = m.pending ? m.liveText || "" : m.content;
  const thinking = m.pending ? m.liveThinking || "" : m.thinking || "";
  const fileIds = m.pending ? m.liveFileIds || [] : m.generatedFileIds;
  const tools = m.pending ? m.liveTools || [] : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className="flex gap-3"
    >
      <div
        className={
          "flex h-7 w-7 flex-none items-center justify-center rounded-md text-[11px] font-semibold " +
          (isUser
            ? "bg-secondary text-foreground"
            : "bg-primary/15 text-primary ring-1 ring-primary/30")
        }
      >
        {isUser ? "you" : "gs"}
      </div>
      <div className="min-w-0 flex-1 space-y-2">
        {!isUser && thinking ? <ThinkingTrace text={thinking} pending={Boolean(m.pending)} /> : null}
        {m.attachments.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {m.attachments.map((a) => (
              <span
                key={a.fileId}
                className="flex items-center gap-1.5 rounded-md border border-border/60 bg-secondary/40 px-2 py-1 text-xs"
              >
                <FileText className="h-3 w-3 text-muted-foreground" />
                {a.name}
              </span>
            ))}
          </div>
        )}
        {text ? <RichText text={text} /> : null}
        {tools.length > 0 && <ToolPills tools={tools} />}
        {!text && m.pending && tools.length === 0 && !thinking ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Thinking…
          </div>
        ) : null}
        {fileIds.length > 0 && <GeneratedFiles ids={fileIds} />}
      </div>
    </motion.div>
  );
}

const TOOL_LABEL: Record<string, { running: string; done: string }> = {
  list_bots: { running: "Listing bots…", done: "Listed bots" },
  get_bot: { running: "Reading bot…", done: "Read bot" },
  create_bot: { running: "Creating bot…", done: "Bot created" },
  update_bot: { running: "Updating bot…", done: "Bot updated" },
  start_bot: { running: "Starting bot…", done: "Bot started" },
  stop_bot: { running: "Stopping bot…", done: "Bot stopped" },
  delete_bot: { running: "Deleting bot…", done: "Bot deleted" },
  tail_bot_log: { running: "Reading log…", done: "Log read" },
  set_bot_script: { running: "Installing script…", done: "Script installed" },
  validate_bot_script: { running: "Validating script…", done: "Script validated" },
  set_bot_autostart: { running: "Configuring 24/7…", done: "24/7 set" },
  list_bot_messages: { running: "Reading bot memory…", done: "Memory read" },
  extract_archive: { running: "Extracting archive…", done: "Archive extracted" },
};

function ToolPills({ tools }: { tools: LiveToolCall[] }) {
  return (
    <div className="flex flex-col gap-1.5">
      {tools.map((t) => {
        const labels = TOOL_LABEL[t.name] ?? {
          running: `Running ${t.name}…`,
          done: t.name,
        };
        const text =
          t.status === "running"
            ? labels.running
            : t.status === "error"
              ? `${labels.done} — failed${t.summary ? `: ${t.summary}` : ""}`
              : `${labels.done}${t.summary ? ` · ${t.summary}` : ""}`;
        return (
          <div
            key={t.id}
            className={
              "flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-xs " +
              (t.status === "running"
                ? "border-primary/30 bg-primary/5 text-primary"
                : t.status === "error"
                  ? "border-destructive/40 bg-destructive/10 text-destructive"
                  : "border-border/60 bg-secondary/40 text-muted-foreground")
            }
          >
            {t.status === "running" ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : t.status === "error" ? (
              <X className="h-3 w-3" />
            ) : (
              <Sparkles className="h-3 w-3" />
            )}
            <span className="font-medium">{text}</span>
          </div>
        );
      })}
    </div>
  );
}

function ThinkingTrace({ text, pending }: { text: string; pending: boolean }) {
  const [open, setOpen] = useState(pending);
  return (
    <div className="rounded-md border border-border/60 bg-secondary/30">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs text-muted-foreground hover:text-foreground"
      >
        {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        <Brain className="h-3 w-3" />
        <span className="font-medium uppercase tracking-wider">
          {pending ? "Thinking…" : "Reasoning"}
        </span>
      </button>
      {open && (
        <div className="border-t border-border/60 px-3 py-2 font-mono text-[12px] leading-relaxed text-muted-foreground whitespace-pre-wrap">
          {text}
          {pending && <span className="ml-1 inline-block h-2.5 w-1 animate-pulse bg-primary/70" />}
        </div>
      )}
    </div>
  );
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(
      null,
      Array.from(bytes.subarray(i, i + chunk)),
    );
  }
  return btoa(binary);
}

export { Download };
