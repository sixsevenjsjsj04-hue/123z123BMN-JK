import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { useVerifyEmail, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Logo } from "@/components/Logo";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { toast } from "sonner";
import { Loader2, Mail } from "lucide-react";

export default function VerifyPage() {
  const [location, navigate] = useLocation();
  const qc = useQueryClient();
  const verify = useVerifyEmail();

  const params = useMemo(() => {
    const search = typeof window !== "undefined" ? window.location.search : "";
    return new URLSearchParams(search);
  }, [location]);

  const email = params.get("email") || "";
  const devCode = params.get("devCode") || "";
  const [code, setCode] = useState(devCode);

  useEffect(() => {
    document.title = "Verify email — GScripts AI";
  }, []);

  useEffect(() => {
    if (!email) navigate("/signup");
  }, [email, navigate]);

  async function submit(value: string) {
    try {
      await verify.mutateAsync({ data: { email, code: value } });
      await qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
      toast.success("Email verified.");
      navigate("/app/chat");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Invalid code";
      toast.error(msg.replace(/^HTTP \d+ \w+:?\s*/, ""));
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="border-b border-border/40 px-6 py-4">
        <Logo />
      </header>
      <main className="flex flex-1 items-center justify-center p-6">
        <Card className="w-full max-w-md border-border/60 bg-card/60 p-8 shadow-2xl shadow-black/40 ring-1 ring-white/5">
          <div className="mb-6 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
            <Mail className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Check your email</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            We sent a 6-digit code to{" "}
            <span className="font-medium text-foreground">{email}</span>.
          </p>
          {devCode ? (
            <div className="mt-4 rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-xs text-foreground/80">
              Dev mode: your code is{" "}
              <span className="font-mono font-semibold text-primary">{devCode}</span>
            </div>
          ) : null}
          <div className="mt-7 flex justify-center">
            <InputOTP
              maxLength={6}
              value={code}
              onChange={(v) => setCode(v)}
              onComplete={(v) => submit(v)}
              data-testid="input-otp"
            >
              <InputOTPGroup>
                {[0, 1, 2, 3, 4, 5].map((i) => (
                  <InputOTPSlot key={i} index={i} />
                ))}
              </InputOTPGroup>
            </InputOTP>
          </div>
          <Button
            className="mt-7 w-full gap-2"
            disabled={code.length < 6 || verify.isPending}
            onClick={() => submit(code)}
            data-testid="button-submit-verify"
          >
            {verify.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Verify and continue
          </Button>
        </Card>
      </main>
    </div>
  );
}
