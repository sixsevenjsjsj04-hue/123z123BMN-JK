import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MarketingNav } from "@/components/MarketingNav";
import {
  Code2,
  Bot,
  FileArchive,
  Search,
  Folder,
  Wand2,
  Cpu,
  ArrowRight,
  CheckCircle2,
  Lock,
} from "lucide-react";
import { motion } from "framer-motion";

const features = [
  {
    icon: Code2,
    title: "Built for vibe coding",
    body: "Python, JavaScript, TypeScript, Lua, and Luau (Roblox). Fluent in the libraries you actually use.",
  },
  {
    icon: Wand2,
    title: "Obfuscators & deobfuscators",
    body: "First-class support for protecting and reverse-engineering JS, Python, and Lua payloads.",
  },
  {
    icon: FileArchive,
    title: "Real files, not just text",
    body: "Generates downloadable scripts, configs, and complete ZIP projects you can ship today.",
  },
  {
    icon: Folder,
    title: "Workspace memory",
    body: "Every file you upload or that GScripts produces lands in your workspace. Search, edit, reuse.",
  },
  {
    icon: Bot,
    title: "Discord bot launcher",
    body: "Drop in a token, hit start. We host it from your workspace and stream the live log.",
  },
  {
    icon: Cpu,
    title: "Thinks before answering",
    body: "Every reply opens with a private reasoning trace, so the answer is structured, not improvised.",
  },
];

const capabilities = [
  "Roblox Luau exploits & anti-cheat patterns",
  "Discord bot scaffolding and event handlers",
  "Python automation and scraping pipelines",
  "JavaScript bundlers, packers, and minifiers",
  "Lua source rewriting & VM-level obfuscation",
  "ZIP project generation with installable scaffolding",
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <MarketingNav />

      <section className="relative overflow-hidden border-b border-border/40">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_30%_-10%,hsl(217_91%_60%/0.15),transparent_60%),radial-gradient(circle_at_75%_10%,hsl(217_91%_60%/0.08),transparent_50%)]" />
        <div className="mx-auto max-w-6xl px-6 py-24 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="max-w-3xl"
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/40 px-3 py-1 text-xs font-medium tracking-wide text-muted-foreground">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
              </span>
              Engineering co-pilot, not a chatbot
            </div>
            <h1 className="mt-6 text-balance text-5xl font-semibold tracking-tight md:text-7xl">
              The AI that ships{" "}
              <span className="bg-gradient-to-br from-foreground to-foreground/60 bg-clip-text text-transparent">
                actual code
              </span>
              .
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground">
              GScripts AI is a focused engineering partner for vibe coders. It writes Python,
              JavaScript, Lua, and Luau scripts, packs them into downloadable ZIPs, runs your
              Discord bots, and keeps every file in a workspace you can search.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="gap-2" data-testid="button-hero-signup">
                <Link href="/signup">
                  Open the workspace
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" data-testid="button-hero-login">
                <Link href="/login">I already have an account</Link>
              </Button>
            </div>
            <div className="mt-8 flex items-center gap-6 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5" /> Verified email & bot challenge
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5" /> Free to start
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.15 }}
            className="mt-20"
          >
            <Card className="overflow-hidden border-border/60 bg-card/60 p-0 shadow-2xl shadow-black/40 ring-1 ring-white/5">
              <div className="flex items-center gap-2 border-b border-border/60 px-4 py-2.5">
                <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-green-500/70" />
                <span className="ml-3 font-mono text-xs text-muted-foreground">
                  gscripts.ai — chat
                </span>
              </div>
              <div className="grid gap-6 p-6 md:grid-cols-2">
                <div className="space-y-3">
                  <div className="rounded-lg border border-border/60 bg-secondary/40 p-3 text-sm">
                    Build me a Roblox Luau anti-AFK loop that survives respawns and includes a
                    toggle GUI.
                  </div>
                  <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm leading-relaxed">
                    <span className="font-mono text-xs text-primary">thinking…</span>
                    <span className="text-muted-foreground">
                      {" "}
                      Anchor in CharacterAdded, expose toggle via ScreenGui keybind, persist
                      state across respawns.
                    </span>
                  </div>
                  <pre className="overflow-hidden rounded-lg border border-border/60 bg-background/60 p-3 font-mono text-[12px] leading-relaxed text-foreground/90">
{`local Players = game:GetService("Players")
local plr = Players.LocalPlayer
local active = true
plr.CharacterAdded:Connect(function(char)
  task.spawn(function()
    while active and char.Parent do
      char:MoveTo(char.PrimaryPart.Position)
      task.wait(120)
    end
  end)
end)`}
                  </pre>
                </div>
                <div className="space-y-3">
                  <div className="rounded-lg border border-border/60 bg-secondary/30 p-3 text-sm">
                    <div className="mb-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
                      <FileArchive className="h-3.5 w-3.5" />
                      Generated artifacts
                    </div>
                    <div className="space-y-1.5">
                      <ArtifactRow name="anti_afk.client.lua" />
                      <ArtifactRow name="toggle_gui.client.lua" />
                      <ArtifactRow name="anti_afk_pack.zip" />
                    </div>
                  </div>
                  <div className="rounded-lg border border-border/60 bg-card/60 p-3 text-sm text-muted-foreground">
                    <div className="mb-1 text-xs font-medium uppercase tracking-wide text-foreground/70">
                      Workspace
                    </div>
                    Every file lands in your workspace. Search across content. Re-deploy from
                    the bots tab.
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>

      <section className="border-b border-border/40">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <h2 className="max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl">
            One workspace for the way you actually build.
          </h2>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Chat, files, and runtime in one place. Everything GScripts writes for you is yours
            to keep, search, and re-run.
          </p>
          <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
              >
                <Card className="h-full border-border/60 bg-card/40 p-5 transition-colors hover:border-primary/40">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md border border-border bg-secondary/60 text-primary">
                    <f.icon className="h-4 w-4" />
                  </div>
                  <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {f.body}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-border/40">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 py-24 md:grid-cols-2">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
              Specialized, not generic.
            </h2>
            <p className="mt-4 text-muted-foreground">
              GScripts AI is tuned for the work that gets built in IDE tabs at 2 a.m. — small
              tools, custom scripts, bots, and obfuscation pipelines that mainstream assistants
              dance around.
            </p>
            <Button asChild className="mt-8 gap-2" data-testid="button-cap-signup">
              <Link href="/signup">
                Try it on a real project
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          <ul className="space-y-3">
            {capabilities.map((c) => (
              <li
                key={c}
                className="flex items-start gap-3 rounded-lg border border-border/60 bg-card/40 p-3 text-sm"
              >
                <CheckCircle2 className="mt-0.5 h-4 w-4 flex-none text-primary" />
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="border-b border-border/40">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <div className="grid gap-10 md:grid-cols-3">
            <div className="md:col-span-1">
              <h2 className="text-3xl font-semibold tracking-tight">How it works</h2>
              <p className="mt-3 text-muted-foreground">
                Three surfaces, one continuous workspace.
              </p>
            </div>
            <div className="grid gap-4 md:col-span-2">
              <Step
                index="01"
                title="Chat that writes files"
                body="Ask in plain language. Attach photos, ZIPs, or source. GScripts streams its reasoning, then drops the finished files into your workspace."
                icon={Code2}
              />
              <Step
                index="02"
                title="Workspace with full-text search"
                body="Browse folders, search across file content, edit text files inline, and download binaries. Everything you and GScripts produced lives here."
                icon={Search}
              />
              <Step
                index="03"
                title="Bots you can actually run"
                body="Paste a Discord token, hit start. We boot the bot, keep it alive, and stream the log so you can watch it react in real time."
                icon={Bot}
              />
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="mx-auto max-w-4xl px-6 py-24 text-center">
          <h2 className="text-balance text-4xl font-semibold tracking-tight md:text-5xl">
            Stop pasting your code into chat windows.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Move it into a workspace that thinks alongside you.
          </p>
          <Button asChild size="lg" className="mt-10 gap-2" data-testid="button-final-signup">
            <Link href="/signup">
              Create your workspace
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-border/40 py-8">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} GScripts AI</span>
          <span className="font-mono">v1.0</span>
        </div>
      </footer>
    </div>
  );
}

function ArtifactRow({ name }: { name: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-border/60 bg-background/40 px-2.5 py-1.5 font-mono text-[12px]">
      <span className="truncate text-foreground/90">{name}</span>
      <span className="text-muted-foreground">download</span>
    </div>
  );
}

function Step({
  index,
  title,
  body,
  icon: Icon,
}: {
  index: string;
  title: string;
  body: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <Card className="flex items-start gap-4 border-border/60 bg-card/40 p-5">
      <div className="font-mono text-xs text-primary">{index}</div>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-base font-semibold">{title}</h3>
        </div>
        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{body}</p>
      </div>
    </Card>
  );
}
