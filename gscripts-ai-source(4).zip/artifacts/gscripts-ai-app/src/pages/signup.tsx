import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { useGetTurnstileConfig, useSignup } from "@workspace/api-client-react";
import { Logo } from "@/components/Logo";
import { Turnstile } from "@/components/turnstile";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export default function SignupPage() {
  const [, navigate] = useLocation();
  const cfg = useGetTurnstileConfig();
  const signup = useSignup();
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");

  useEffect(() => {
    document.title = "Create account — GScripts AI";
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }
    if (!token) {
      toast.error("Please complete the verification challenge.");
      return;
    }
    try {
      const res = await signup.mutateAsync({
        data: { email, password, displayName, turnstileToken: token },
      });
      const params = new URLSearchParams({ email: res.email });
      if (res.devCode) params.set("devCode", res.devCode);
      navigate(`/verify?${params.toString()}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Signup failed";
      toast.error(msg.replace(/^HTTP \d+ \w+:?\s*/, ""));
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="border-b border-border/40 px-6 py-4">
        <Logo />
      </header>
      <main className="flex flex-1 items-center justify-center p-6">
        <Card className="w-full max-w-md border-border/60 bg-card/60 p-8 shadow-2xl shadow-black/40 ring-1 ring-white/5">
          <div className="mb-7">
            <h1 className="text-2xl font-semibold tracking-tight">Create your workspace</h1>
            <p className="mt-1.5 text-sm text-muted-foreground">
              We'll send a 6-digit code to verify your email.
            </p>
          </div>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="displayName">Display name</Label>
              <Input
                id="displayName"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                data-testid="input-display-name"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="input-email"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
                data-testid="input-password"
              />
              <p className="text-xs text-muted-foreground">At least 8 characters.</p>
            </div>
            <div className="pt-1">
              {cfg.data?.siteKey ? (
                <Turnstile siteKey={cfg.data.siteKey} onToken={setToken} />
              ) : (
                <div className="h-[65px] rounded-md border border-dashed border-border/60 px-3 py-4 text-xs text-muted-foreground">
                  Loading verification…
                </div>
              )}
            </div>
            <Button
              type="submit"
              className="w-full gap-2"
              disabled={signup.isPending}
              data-testid="button-submit-signup"
            >
              {signup.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Continue
            </Button>
          </form>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="text-primary hover:underline" data-testid="link-go-login">
              Sign in
            </Link>
          </p>
        </Card>
      </main>
    </div>
  );
}
