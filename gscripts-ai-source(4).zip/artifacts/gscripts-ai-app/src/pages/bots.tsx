import { useState } from "react";
import {
  useListBots,
  useCreateBot,
  useDeleteBot,
  useStartBot,
  useStopBot,
  getListBotsQueryKey,
  type Bot,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import {
  Bot as BotIcon,
  Plus,
  Play,
  Square,
  Trash2,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { formatRelativeTime } from "@/lib/format";

export default function BotsPage() {
  const list = useListBots({
    query: {
      queryKey: getListBotsQueryKey(),
      refetchInterval: 5000,
    },
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = list.data?.find((b) => b.id === selectedId) ?? null;

  return (
    <div className="flex h-full">
      <div className="flex w-80 flex-none flex-col border-r border-border/60 bg-card/30">
        <div className="flex items-center justify-between border-b border-border/60 px-4 py-3">
          <div>
            <h2 className="text-sm font-semibold">Bots</h2>
            <p className="text-[11px] text-muted-foreground">Discord launchers</p>
          </div>
          <NewBotDialog onCreated={(id) => setSelectedId(id)} />
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {list.isLoading ? (
            <div className="px-3 py-6 text-xs text-muted-foreground">Loading…</div>
          ) : (list.data?.length ?? 0) === 0 ? (
            <div className="px-3 py-6 text-xs text-muted-foreground">
              No bots yet. Add one to get started.
            </div>
          ) : (
            <ul className="space-y-1">
              {list.data!.map((b) => (
                <li key={b.id}>
                  <button
                    onClick={() => setSelectedId(b.id)}
                    className={
                      "flex w-full items-center gap-2 rounded-md px-2 py-2 text-left transition-colors " +
                      (selectedId === b.id
                        ? "bg-secondary text-foreground"
                        : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground")
                    }
                    data-testid={`button-bot-${b.id}`}
                  >
                    <BotIcon className="h-4 w-4 flex-none opacity-80" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{b.name}</div>
                      <div className="truncate text-[11px] text-muted-foreground">
                        {b.platform}
                      </div>
                    </div>
                    <StatusPill status={b.status} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        {selected ? (
          <BotDetail bot={selected} />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Select a bot to view its log and controls.
          </div>
        )}
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    running: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    stopped: "bg-secondary text-muted-foreground border-border/60",
    error: "bg-red-500/15 text-red-400 border-red-500/30",
  };
  return (
    <span
      className={
        "rounded-full border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide " +
        (map[status] ?? map.stopped)
      }
    >
      {status}
    </span>
  );
}

function NewBotDialog({ onCreated }: { onCreated: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [token, setToken] = useState("");
  const create = useCreateBot();
  const qc = useQueryClient();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name || !token) {
      toast.error("Both name and token are required.");
      return;
    }
    try {
      const res = await create.mutateAsync({ data: { name, token } });
      await qc.invalidateQueries({ queryKey: getListBotsQueryKey() });
      setName("");
      setToken("");
      setOpen(false);
      onCreated(res.id);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(msg);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1" data-testid="button-add-bot">
          <Plus className="h-3.5 w-3.5" />
          Add
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Discord bot</DialogTitle>
          <DialogDescription>
            Paste the token from your Discord Developer Portal. We store it in your workspace
            and never display it again.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="bot-name">Name</Label>
            <Input
              id="bot-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="My helper bot"
              data-testid="input-bot-name"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="bot-token">Bot token</Label>
            <Input
              id="bot-token"
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="MTAxOTI..."
              data-testid="input-bot-token"
            />
          </div>
          <Button type="submit" className="w-full gap-2" disabled={create.isPending}>
            {create.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Add bot
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function BotDetail({ bot }: { bot: Bot }) {
  const start = useStartBot();
  const stop = useStopBot();
  const del = useDeleteBot();
  const qc = useQueryClient();

  async function doStart() {
    try {
      await start.mutateAsync({ id: bot.id });
      await qc.invalidateQueries({ queryKey: getListBotsQueryKey() });
      toast.success(`${bot.name} started`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed";
      toast.error(msg);
    }
  }

  async function doStop() {
    try {
      await stop.mutateAsync({ id: bot.id });
      await qc.invalidateQueries({ queryKey: getListBotsQueryKey() });
    } catch {
      toast.error("Failed to stop");
    }
  }

  async function doDelete() {
    if (!confirm(`Delete ${bot.name}?`)) return;
    try {
      await del.mutateAsync({ id: bot.id });
      await qc.invalidateQueries({ queryKey: getListBotsQueryKey() });
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between border-b border-border/60 bg-card/30 px-6 py-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold">{bot.name}</h2>
            <StatusPill status={bot.status} />
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {bot.platform} · created {formatRelativeTime(bot.createdAt)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {bot.status === "running" ? (
            <Button onClick={doStop} variant="outline" size="sm" disabled={stop.isPending} data-testid="button-stop">
              <Square className="mr-1.5 h-3.5 w-3.5" />
              Stop
            </Button>
          ) : (
            <Button onClick={doStart} size="sm" disabled={start.isPending} data-testid="button-start">
              <Play className="mr-1.5 h-3.5 w-3.5" />
              Start
            </Button>
          )}
          <Button
            onClick={doDelete}
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-destructive"
            data-testid="button-delete-bot"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </header>
      <div className="flex-1 space-y-3 overflow-auto p-6">
        {bot.lastError && (
          <Card className="border-red-500/30 bg-red-500/5 p-3 text-sm">
            <div className="flex items-start gap-2 text-red-400">
              <AlertCircle className="mt-0.5 h-4 w-4 flex-none" />
              <div>
                <div className="font-medium">Last error</div>
                <div className="mt-0.5 font-mono text-[12px] text-red-300/80">
                  {bot.lastError}
                </div>
              </div>
            </div>
          </Card>
        )}
        <div>
          <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Live log
          </div>
          <pre className="h-[60vh] overflow-auto rounded-md border border-border/60 bg-black/60 p-3 font-mono text-[12px] leading-relaxed text-emerald-300/90">
            {bot.log || "No log yet. Start the bot to see output."}
          </pre>
        </div>
      </div>
    </div>
  );
}
