import { useEffect, useMemo, useState } from "react";
import {
  useListFiles,
  useGetFile,
  useDeleteFile,
  useUpdateFile,
  useUploadFile,
  getListFilesQueryKey,
  type FileMeta,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Search,
  FileText,
  FileArchive,
  FileCode2,
  Trash2,
  Download,
  Save,
  Sparkles,
  UploadCloud,
  Loader2,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { formatBytes, formatRelativeTime, isTextLikeMime } from "@/lib/format";
import { toast } from "sonner";

export default function WorkspacePage() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "user_upload" | "ai_generated">("all");
  const list = useListFiles({ q: query || undefined });
  const upload = useUploadFile();
  const qc = useQueryClient();

  const grouped = useMemo(() => {
    const out = new Map<string, FileMeta[]>();
    for (const f of list.data ?? []) {
      if (filter !== "all" && f.source !== filter) continue;
      const folder = f.folder || "/";
      if (!out.has(folder)) out.set(folder, []);
      out.get(folder)!.push(f);
    }
    return Array.from(out.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [list.data, filter]);

  useEffect(() => {
    if (selected && list.data && !list.data.some((f) => f.id === selected)) {
      setSelected(null);
    }
  }, [list.data, selected]);

  async function handleUpload(files: FileList | null) {
    if (!files) return;
    for (const f of Array.from(files)) {
      if (f.size > 10 * 1024 * 1024) {
        toast.error(`${f.name} is over 10MB and was skipped.`);
        continue;
      }
      try {
        const isText = isTextLikeMime(f.type || "text/plain");
        let content: string | null = null;
        let dataB64: string | null = null;
        if (isText) content = await f.text();
        else {
          const buf = await f.arrayBuffer();
          dataB64 = arrayBufferToBase64(buf);
        }
        await upload.mutateAsync({
          data: {
            name: f.name,
            mimeType: f.type || "application/octet-stream",
            size: f.size,
            folder: "/uploads",
            content,
            dataB64,
          },
        });
      } catch {
        toast.error(`Failed to upload ${f.name}`);
      }
    }
    await qc.invalidateQueries({ queryKey: getListFilesQueryKey() });
  }

  return (
    <div className="flex h-full">
      <div className="flex w-80 flex-none flex-col border-r border-border/60 bg-card/30">
        <div className="border-b border-border/60 p-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search files & contents"
              className="h-8 pl-8 text-sm"
              data-testid="input-search-files"
            />
          </div>
          <div className="mt-2 flex gap-1">
            {(
              [
                { v: "all", label: "All" },
                { v: "ai_generated", label: "AI" },
                { v: "user_upload", label: "Uploads" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.v}
                onClick={() => setFilter(opt.v)}
                className={
                  "flex-1 rounded-md px-2 py-1 text-[11px] font-medium transition-colors " +
                  (filter === opt.v
                    ? "bg-secondary text-foreground"
                    : "text-muted-foreground hover:bg-secondary/40")
                }
                data-testid={`button-filter-${opt.v}`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <label className="mt-2 flex cursor-pointer items-center justify-center gap-1.5 rounded-md border border-dashed border-border/60 px-2 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground">
            <UploadCloud className="h-3.5 w-3.5" />
            {upload.isPending ? "Uploading…" : "Upload files"}
            <input
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                handleUpload(e.target.files);
                e.currentTarget.value = "";
              }}
              data-testid="input-workspace-upload"
            />
          </label>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {list.isLoading ? (
            <div className="px-3 py-6 text-xs text-muted-foreground">Loading…</div>
          ) : grouped.length === 0 ? (
            <div className="px-3 py-6 text-xs text-muted-foreground">
              No files yet. Upload one or ask GScripts to generate.
            </div>
          ) : (
            grouped.map(([folder, files]) => (
              <div key={folder} className="mb-3">
                <div className="px-2 py-1 text-[10.5px] font-medium uppercase tracking-wider text-muted-foreground">
                  {folder}
                </div>
                <ul className="space-y-0.5">
                  {files.map((f) => {
                    const Icon = pickIcon(f.mimeType);
                    const active = selected === f.id;
                    return (
                      <li key={f.id}>
                        <button
                          onClick={() => setSelected(f.id)}
                          className={
                            "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition-colors " +
                            (active
                              ? "bg-secondary text-foreground"
                              : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground")
                          }
                          data-testid={`button-file-${f.id}`}
                        >
                          <Icon className="h-3.5 w-3.5 flex-none opacity-70" />
                          <span className="flex-1 truncate">{f.name}</span>
                          {f.source === "ai_generated" && (
                            <Sparkles className="h-3 w-3 flex-none text-primary" />
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))
          )}
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        {selected ? (
          <FileViewer id={selected} onClose={() => setSelected(null)} />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Select a file to view.
          </div>
        )}
      </div>
    </div>
  );
}

function FileViewer({ id, onClose }: { id: string; onClose: () => void }) {
  const file = useGetFile(id);
  const update = useUpdateFile();
  const del = useDeleteFile();
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");

  useEffect(() => {
    if (file.data?.content != null) {
      setText(file.data.content);
      setEditing(false);
    }
  }, [file.data]);

  if (file.isLoading || !file.data) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        Loading file…
      </div>
    );
  }

  const f = file.data;
  const isText = f.content != null;

  async function save() {
    try {
      await update.mutateAsync({ id, data: { content: text } });
      await qc.invalidateQueries({ queryKey: getListFilesQueryKey() });
      toast.success("Saved");
      setEditing(false);
    } catch {
      toast.error("Failed to save");
    }
  }

  function downloadIt() {
    let blob: Blob;
    if (f.content != null) blob = new Blob([f.content], { type: f.mimeType });
    else if (f.dataB64) {
      const binary = atob(f.dataB64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      blob = new Blob([bytes], { type: f.mimeType });
    } else {
      blob = new Blob([], { type: f.mimeType });
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = f.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function remove() {
    if (!confirm(`Delete ${f.name}?`)) return;
    try {
      await del.mutateAsync({ id });
      await qc.invalidateQueries({ queryKey: getListFilesQueryKey() });
      onClose();
    } catch {
      toast.error("Failed to delete");
    }
  }

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between border-b border-border/60 bg-card/30 px-5 py-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h2 className="truncate text-sm font-medium" data-testid="text-file-name">
              {f.name}
            </h2>
            <span
              className={
                "rounded-full px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide " +
                (f.source === "ai_generated"
                  ? "bg-primary/15 text-primary"
                  : "bg-secondary text-muted-foreground")
              }
            >
              {f.source === "ai_generated" ? "AI" : "Upload"}
            </span>
          </div>
          <div className="mt-0.5 text-xs text-muted-foreground">
            {f.folder} · {f.mimeType} · {formatBytes(f.size)} ·{" "}
            {formatRelativeTime(f.updatedAt)}
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          {isText && editing && (
            <Button size="sm" onClick={save} disabled={update.isPending} data-testid="button-save">
              <Save className="mr-1.5 h-3.5 w-3.5" />
              Save
            </Button>
          )}
          {isText && !editing && (
            <Button size="sm" variant="outline" onClick={() => setEditing(true)} data-testid="button-edit">
              Edit
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={downloadIt} data-testid="button-download">
            <Download className="mr-1.5 h-3.5 w-3.5" />
            Download
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="text-muted-foreground hover:text-destructive"
            onClick={remove}
            data-testid="button-delete"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </header>
      <div className="flex-1 overflow-auto bg-background/60 p-5">
        {isText ? (
          editing ? (
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="min-h-full w-full resize-none border-border/60 bg-card/40 font-mono text-[12.5px] leading-relaxed"
              data-testid="textarea-file-content"
            />
          ) : (
            <pre className="overflow-x-auto rounded-md border border-border/60 bg-card/40 p-4 font-mono text-[12.5px] leading-relaxed text-foreground/90">
              <code>{f.content}</code>
            </pre>
          )
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Binary file. Use Download to save it.
          </div>
        )}
      </div>
    </div>
  );
}

function pickIcon(mime: string) {
  if (mime === "application/zip") return FileArchive;
  if (mime.startsWith("text/") || mime.includes("script") || mime.includes("json")) return FileCode2;
  return FileText;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
  }
  return btoa(binary);
}
