import { Link } from "wouter";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";

export function MarketingNav() {
  return (
    <nav className="sticky top-0 z-30 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
        <Logo />
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost" size="sm" data-testid="link-nav-login">
            <Link href="/login">Sign in</Link>
          </Button>
          <Button asChild size="sm" data-testid="link-nav-signup">
            <Link href="/signup">Get started</Link>
          </Button>
        </div>
      </div>
    </nav>
  );
}
