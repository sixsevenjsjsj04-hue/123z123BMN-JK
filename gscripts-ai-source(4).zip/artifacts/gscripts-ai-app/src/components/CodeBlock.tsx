import { useState } from "react";
import { Check, Copy } from "lucide-react";

export function CodeBlock({ code, lang }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);

  function copy() {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="group relative my-2 overflow-hidden rounded-lg border border-border/60 bg-background/60">
      <div className="flex items-center justify-between border-b border-border/40 px-3 py-1.5">
        <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
          {lang || "code"}
        </span>
        <button
          onClick={copy}
          className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground"
          aria-label="Copy code"
        >
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 font-mono text-[12.5px] leading-relaxed text-foreground/90">
        <code>{code}</code>
      </pre>
    </div>
  );
}

// Simple markdown-ish renderer: handles ```fenced``` and `inline` code, plus paragraphs.
export function RichText({ text }: { text: string }) {
  const parts: Array<
    { kind: "text"; value: string } | { kind: "code"; value: string; lang?: string }
  > = [];

  const re = /```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    if (m.index > lastIndex) {
      parts.push({ kind: "text", value: text.slice(lastIndex, m.index) });
    }
    parts.push({ kind: "code", lang: m[1] || undefined, value: m[2].replace(/\n$/, "") });
    lastIndex = m.index + m[0].length;
  }
  if (lastIndex < text.length) {
    parts.push({ kind: "text", value: text.slice(lastIndex) });
  }

  return (
    <div className="space-y-2 text-[14.5px] leading-relaxed">
      {parts.map((p, i) => {
        if (p.kind === "code") return <CodeBlock key={i} code={p.value} lang={p.lang} />;
        return (
          <div key={i}>
            {p.value.split(/\n{2,}/).map((para, j) => (
              <p key={j} className="whitespace-pre-wrap [&:not(:first-child)]:mt-2">
                <InlineText text={para} />
              </p>
            ))}
          </div>
        );
      })}
    </div>
  );
}

function InlineText({ text }: { text: string }) {
  const re = /`([^`]+)`/g;
  const out: React.ReactNode[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  let key = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index));
    out.push(
      <code
        key={key++}
        className="rounded border border-border/60 bg-secondary/60 px-1 py-px font-mono text-[12.5px]"
      >
        {m[1]}
      </code>,
    );
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(text.slice(last));
  return <>{out}</>;
}
