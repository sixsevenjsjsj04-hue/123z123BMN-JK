import { useQueries } from "@tanstack/react-query";
import {
  getFile,
  getGetFileQueryKey,
} from "@workspace/api-client-react";
import { Download, FileArchive, FileCode2, FileText } from "lucide-react";
import { formatBytes } from "@/lib/format";

export function GeneratedFiles({ ids }: { ids: string[] }) {
  const queries = useQueries({
    queries: ids.map((id) => ({
      queryKey: getGetFileQueryKey(id),
      queryFn: () => getFile(id),
      staleTime: 5 * 60 * 1000,
    })),
  });

  return (
    <div className="space-y-1.5 rounded-md border border-border/60 bg-card/40 p-2">
      <div className="px-2 py-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        Generated files
      </div>
      <div className="grid gap-1.5 sm:grid-cols-2">
        {queries.map((q, i) => {
          const file = q.data;
          if (!file) {
            return (
              <div
                key={ids[i]}
                className="flex items-center gap-2 rounded-md border border-border/60 bg-background/40 px-2 py-1.5 text-xs text-muted-foreground"
              >
                Loading…
              </div>
            );
          }
          const Icon = pickIcon(file.mimeType);
          return (
            <button
              key={file.id}
              onClick={() => downloadFile(file)}
              className="group flex items-center gap-2 rounded-md border border-border/60 bg-background/40 px-2 py-1.5 text-left text-xs transition-colors hover:border-primary/40 hover:bg-primary/5"
              data-testid={`button-download-${file.id}`}
            >
              <Icon className="h-3.5 w-3.5 flex-none text-primary" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium text-foreground">{file.name}</div>
                <div className="truncate text-[10.5px] text-muted-foreground">
                  {file.mimeType} · {formatBytes(file.size)}
                </div>
              </div>
              <Download className="h-3 w-3 flex-none text-muted-foreground transition-colors group-hover:text-primary" />
            </button>
          );
        })}
      </div>
    </div>
  );
}

function pickIcon(mime: string) {
  if (mime === "application/zip") return FileArchive;
  if (mime.startsWith("text/") || mime.includes("script") || mime.includes("json")) return FileCode2;
  return FileText;
}

function downloadFile(file: {
  name: string;
  mimeType: string;
  content?: string | null;
  dataB64?: string | null;
}) {
  let blob: Blob;
  if (file.content != null) {
    blob = new Blob([file.content], { type: file.mimeType });
  } else if (file.dataB64) {
    const binary = atob(file.dataB64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    blob = new Blob([bytes], { type: file.mimeType });
  } else {
    blob = new Blob([], { type: file.mimeType });
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
