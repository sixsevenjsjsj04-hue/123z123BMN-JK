import { Link } from "wouter";

export function Logo({ to = "/" }: { to?: string }) {
  return (
    <Link href={to} className="flex items-center gap-2 group" data-testid="link-logo">
      <div className="relative flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-primary/80 to-primary shadow-lg shadow-primary/20 ring-1 ring-white/10 transition-transform group-hover:scale-105">
        <span className="font-mono text-[15px] font-bold leading-none text-primary-foreground">
          gs
        </span>
      </div>
      <span className="text-[15px] font-semibold tracking-tight text-foreground">
        GScripts <span className="text-primary">AI</span>
      </span>
    </Link>
  );
}
