export type StreamEvent =
  | { type: "thinking"; content: string }
  | { type: "delta"; content: string }
  | { type: "files"; fileIds: string[] }
  | { type: "tool_use"; name: string; input: Record<string, unknown> }
  | { type: "tool_result"; name: string; ok: boolean; summary?: string }
  | { type: "done"; cleanText?: string }
  | { type: "error"; message: string };

export async function streamMessage(
  conversationId: string,
  body: { content: string; attachmentFileIds?: string[] },
  basePath: string,
  onEvent: (e: StreamEvent) => void,
): Promise<void> {
  const apiBase = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? "";
  const prefix = apiBase
    ? apiBase.replace(/\/$/, "")
    : basePath.replace(/\/$/, "");
  const url = `${prefix}/api/chat/conversations/${conversationId}/messages`;
  const res = await fetch(url, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json", Accept: "text/event-stream" },
    body: JSON.stringify(body),
  });
  if (!res.ok || !res.body) {
    let text = "";
    try {
      text = await res.text();
    } catch {
      // ignore
    }
    throw new Error(`Stream failed (${res.status}): ${text || res.statusText}`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";

  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });

    let idx: number;
    while ((idx = buf.indexOf("\n\n")) !== -1) {
      const ev = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 2);
      if (!ev.startsWith("data:")) continue;
      const json = ev.slice(5).trim();
      if (!json) continue;
      try {
        const parsed = JSON.parse(json) as StreamEvent;
        onEvent(parsed);
      } catch {
        // ignore malformed event
      }
    }
  }
}
