import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "sonner";
import LandingPage from "@/pages/landing";
import LoginPage from "@/pages/login";
import SignupPage from "@/pages/signup";
import VerifyPage from "@/pages/verify";
import ChatPage from "@/pages/chat";
import WorkspacePage from "@/pages/workspace";
import BotsPage from "@/pages/bots";
import NotFound from "@/pages/not-found";
import { AppLayout } from "@/pages/app-layout";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function AppRouter() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/signup" component={SignupPage} />
      <Route path="/verify" component={VerifyPage} />

      <Route path="/app">
        {() => <Redirect to="/app/chat" />}
      </Route>
      <Route path="/app/chat">
        {() => (
          <AppLayout>
            <ChatPage />
          </AppLayout>
        )}
      </Route>
      <Route path="/app/chat/:id">
        {() => (
          <AppLayout>
            <ChatPage />
          </AppLayout>
        )}
      </Route>
      <Route path="/app/workspace">
        {() => (
          <AppLayout>
            <WorkspacePage />
          </AppLayout>
        )}
      </Route>
      <Route path="/app/bots">
        {() => (
          <AppLayout>
            <BotsPage />
          </AppLayout>
        )}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AppRouter />
        </WouterRouter>
        <Toaster richColors position="bottom-right" theme="dark" />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
