const TURNSTILE_VERIFY_URL =
  "https://challenges.cloudflare.com/turnstile/v0/siteverify";

// Cloudflare-published always-pass test keys for development.
const DEV_SITE_KEY = "1x00000000000000000000AA";
const DEV_SECRET_KEY = "1x0000000000000000000000000000000AA";

export function getTurnstileSiteKey(): string {
  return process.env.TURNSTILE_SITE_KEY || DEV_SITE_KEY;
}

export async function verifyTurnstile(token: string, ip?: string): Promise<boolean> {
  if (!token) return false;
  const secret = process.env.TURNSTILE_SECRET_KEY || DEV_SECRET_KEY;
  const params = new URLSearchParams();
  params.set("secret", secret);
  params.set("response", token);
  if (ip) params.set("remoteip", ip);

  try {
    const r = await fetch(TURNSTILE_VERIFY_URL, {
      method: "POST",
      body: params,
    });
    const data = (await r.json()) as { success?: boolean };
    return Boolean(data.success);
  } catch {
    return false;
  }
}
