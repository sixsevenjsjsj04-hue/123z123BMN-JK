import JSZip from "jszip";
import * as tar from "tar";
import { Readable } from "node:stream";
import { mkdtempSync, createWriteStream, rmSync, readFileSync, statSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import type { FileRow } from "@workspace/db";

export type ExtractedEntry = {
  path: string;
  size: number;
  isText: boolean;
  preview: string | null;
  truncated: boolean;
};

const TEXT_EXT = new Set([
  ".txt", ".md", ".json", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
  ".py", ".lua", ".luau", ".rb", ".go", ".rs", ".java", ".kt", ".cs",
  ".html", ".htm", ".css", ".scss", ".less", ".vue", ".svelte",
  ".yaml", ".yml", ".toml", ".ini", ".env", ".cfg", ".conf",
  ".sh", ".bash", ".zsh", ".ps1", ".bat",
  ".xml", ".csv", ".tsv", ".sql", ".graphql", ".gql",
  ".dockerfile", ".gitignore", ".editorconfig", ".prettierrc", ".eslintrc",
]);

function isLikelyText(name: string, mime?: string | null): boolean {
  if (mime && (mime.startsWith("text/") || mime.includes("json") || mime.includes("xml"))) return true;
  const ext = path.extname(name).toLowerCase();
  if (!ext) {
    const base = path.basename(name).toLowerCase();
    if (["readme", "license", "makefile", "dockerfile"].includes(base)) return true;
  }
  return TEXT_EXT.has(ext);
}

function fileToBuffer(f: FileRow): Buffer {
  if (f.dataB64) return Buffer.from(f.dataB64, "base64");
  if (f.content !== null && f.content !== undefined) return Buffer.from(f.content, "utf8");
  throw new Error("File has no content or data");
}

function isZip(name: string, mime: string): boolean {
  if (mime.includes("zip")) return true;
  return name.toLowerCase().endsWith(".zip");
}

function isTar(name: string, mime: string): boolean {
  const lower = name.toLowerCase();
  if (mime.includes("tar") || mime.includes("gzip")) return true;
  return (
    lower.endsWith(".tar") ||
    lower.endsWith(".tar.gz") ||
    lower.endsWith(".tgz") ||
    lower.endsWith(".tar.bz2")
  );
}

export async function extractArchiveFromFile(
  f: FileRow,
  opts: { maxEntries: number; maxBytesPerEntry: number },
): Promise<ExtractedEntry[]> {
  const buf = fileToBuffer(f);

  if (isZip(f.name, f.mimeType)) {
    return extractZip(buf, opts);
  }
  if (isTar(f.name, f.mimeType)) {
    return extractTar(buf, f.name, opts);
  }
  throw new Error(`Unsupported archive type: ${f.name} (${f.mimeType})`);
}

async function extractZip(
  buf: Buffer,
  opts: { maxEntries: number; maxBytesPerEntry: number },
): Promise<ExtractedEntry[]> {
  const zip = await JSZip.loadAsync(buf);
  const entries: ExtractedEntry[] = [];
  const names = Object.keys(zip.files);
  for (const name of names) {
    if (entries.length >= opts.maxEntries) break;
    const zf = zip.files[name];
    if (zf.dir) continue;
    const text = isLikelyText(name);
    if (text) {
      const content = await zf.async("string");
      const truncated = content.length > opts.maxBytesPerEntry;
      entries.push({
        path: name,
        size: content.length,
        isText: true,
        preview: truncated ? content.slice(0, opts.maxBytesPerEntry) : content,
        truncated,
      });
    } else {
      const data = await zf.async("uint8array");
      entries.push({
        path: name,
        size: data.length,
        isText: false,
        preview: null,
        truncated: false,
      });
    }
  }
  return entries;
}

async function extractTar(
  buf: Buffer,
  name: string,
  opts: { maxEntries: number; maxBytesPerEntry: number },
): Promise<ExtractedEntry[]> {
  // Stream the buffer through tar to a temporary directory, then walk it.
  const dir = mkdtempSync(path.join(tmpdir(), "gs-tar-"));
  const archivePath = path.join(dir, "archive.bin");
  await new Promise<void>((resolve, reject) => {
    const out = createWriteStream(archivePath);
    out.on("error", reject);
    out.on("finish", () => resolve());
    Readable.from(buf).pipe(out);
  });
  const outDir = path.join(dir, "out");
  try {
    await tar.x({
      file: archivePath,
      cwd: outDir,
      C: outDir,
      strict: false,
      sync: false,
      noChmod: true,
      // tar will auto-detect .tar.gz
    } as unknown as Parameters<typeof tar.x>[0]);
  } catch (e) {
    rmSync(dir, { recursive: true, force: true });
    throw new Error(`Failed to extract tar (${name}): ${e instanceof Error ? e.message : String(e)}`);
  }

  const entries: ExtractedEntry[] = [];
  const walk = (current: string) => {
    if (entries.length >= opts.maxEntries) return;
    let items: string[] = [];
    try {
      items = readdirSync(current);
    } catch {
      return;
    }
    for (const item of items) {
      if (entries.length >= opts.maxEntries) return;
      const full = path.join(current, item);
      let s;
      try {
        s = statSync(full);
      } catch {
        continue;
      }
      if (s.isDirectory()) {
        walk(full);
        continue;
      }
      const rel = path.relative(outDir, full);
      const text = isLikelyText(rel);
      if (text) {
        try {
          const content = readFileSync(full, "utf8");
          const truncated = content.length > opts.maxBytesPerEntry;
          entries.push({
            path: rel,
            size: s.size,
            isText: true,
            preview: truncated ? content.slice(0, opts.maxBytesPerEntry) : content,
            truncated,
          });
        } catch {
          entries.push({
            path: rel,
            size: s.size,
            isText: false,
            preview: null,
            truncated: false,
          });
        }
      } else {
        entries.push({
          path: rel,
          size: s.size,
          isText: false,
          preview: null,
          truncated: false,
        });
      }
    }
  };
  walk(outDir);
  rmSync(dir, { recursive: true, force: true });
  return entries;
}
