import { Client, GatewayIntentBits, Events, type Message as DJSMessage } from "discord.js";
import { eq } from "drizzle-orm";
import vm from "node:vm";
import { db, bots, type Bot } from "@workspace/db";
import { logger } from "./logger";

type Running = {
  client: Client;
  startedAt: Date;
  scriptHandler:
    | ((ctx: BotScriptContext) => unknown | Promise<unknown>)
    | null;
};

type BotScriptContext = {
  message: {
    content: string;
    authorId: string;
    authorTag: string;
    channelId: string;
    guildId: string | null;
    isBot: boolean;
  };
  reply: (text: string) => Promise<void>;
  send: (channelId: string, text: string) => Promise<void>;
  log: (line: string) => Promise<void>;
};

const runningBots = new Map<string, Running>();
const recentMessages = new Map<string, Array<{ at: number; channelId: string; text: string }>>();

const MAX_LOG_CHARS = 16000;
const MAX_REMEMBERED = 200;

async function appendLog(botId: string, line: string): Promise<void> {
  const stamp = new Date().toISOString();
  const entry = `[${stamp}] ${line}\n`;
  const [row] = await db.select().from(bots).where(eq(bots.id, botId)).limit(1);
  if (!row) return;
  let next = (row.log || "") + entry;
  if (next.length > MAX_LOG_CHARS) {
    next = next.slice(next.length - MAX_LOG_CHARS);
  }
  await db
    .update(bots)
    .set({ log: next, updatedAt: new Date() })
    .where(eq(bots.id, botId));
}

function rememberMessage(botId: string, channelId: string, text: string) {
  const arr = recentMessages.get(botId) ?? [];
  arr.push({ at: Date.now(), channelId, text });
  if (arr.length > MAX_REMEMBERED) arr.splice(0, arr.length - MAX_REMEMBERED);
  recentMessages.set(botId, arr);
}

export function getRecentBotMessages(botId: string, limit = 50) {
  const arr = recentMessages.get(botId) ?? [];
  return arr.slice(-limit);
}

export function isBotRunning(botId: string): boolean {
  return runningBots.has(botId);
}

function compileScript(code: string): (ctx: BotScriptContext) => unknown {
  // Wrap user code in an async function. The script body has access to `ctx`.
  const wrapped = `(async (ctx) => { ${code}\n})`;
  const script = new vm.Script(wrapped, { filename: "bot-script.js" });
  const sandbox: Record<string, unknown> = {
    console,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    fetch: globalThis.fetch,
    URL,
    URLSearchParams,
    JSON,
    Math,
    Date,
    Promise,
    Buffer,
  };
  vm.createContext(sandbox);
  const fn = script.runInContext(sandbox) as (ctx: BotScriptContext) => Promise<unknown>;
  return fn;
}

export async function startBot(bot: Bot): Promise<void> {
  if (runningBots.has(bot.id)) return;

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
    ],
  });

  let scriptHandler: ((ctx: BotScriptContext) => unknown | Promise<unknown>) | null = null;
  if (bot.script && bot.script.trim()) {
    try {
      scriptHandler = compileScript(bot.script);
      await appendLog(bot.id, "Custom script compiled OK");
    } catch (e) {
      const m = e instanceof Error ? e.message : String(e);
      await appendLog(bot.id, `Script compile error: ${m}`);
      scriptHandler = null;
    }
  }

  client.once(Events.ClientReady, async (c) => {
    await appendLog(bot.id, `Logged in as ${c.user.tag}`);
    await db
      .update(bots)
      .set({ status: "running", lastError: null, updatedAt: new Date() })
      .where(eq(bots.id, bot.id));
  });

  client.on(Events.MessageCreate, async (msg: DJSMessage) => {
    if (msg.author.bot) return;
    const text = msg.content?.trim() ?? "";
    if (!text) return;

    // Built-in safety commands always work
    if (text === "!ping") {
      const sent = await msg.reply("pong");
      rememberMessage(bot.id, msg.channelId, "pong");
      await appendLog(bot.id, `[${msg.author.tag}] ${text}  ->  pong (${sent.id})`);
      return;
    }
    if (text.toLowerCase().startsWith("!echo ")) {
      const out = text.slice(6);
      const sent = await msg.reply(out);
      rememberMessage(bot.id, msg.channelId, out);
      await appendLog(bot.id, `[${msg.author.tag}] ${text}  ->  echo (${sent.id})`);
      return;
    }

    // Custom script handler
    if (scriptHandler) {
      const ctx: BotScriptContext = {
        message: {
          content: text,
          authorId: msg.author.id,
          authorTag: msg.author.tag,
          channelId: msg.channelId,
          guildId: msg.guildId,
          isBot: msg.author.bot,
        },
        reply: async (out) => {
          const sent = await msg.reply(out.slice(0, 2000));
          rememberMessage(bot.id, msg.channelId, out);
          await appendLog(bot.id, `reply -> ${sent.id}: ${out.slice(0, 120)}`);
        },
        send: async (channelId, out) => {
          const ch = await client.channels.fetch(channelId);
          if (ch && "send" in ch && typeof (ch as { send?: unknown }).send === "function") {
            const sent = await (ch as unknown as { send: (s: string) => Promise<{ id: string }> })
              .send(out.slice(0, 2000));
            rememberMessage(bot.id, channelId, out);
            await appendLog(bot.id, `send -> ${sent.id}: ${out.slice(0, 120)}`);
          }
        },
        log: async (line) => {
          await appendLog(bot.id, `script: ${line}`);
        },
      };
      try {
        await scriptHandler(ctx);
      } catch (e) {
        const m = e instanceof Error ? e.message : String(e);
        await appendLog(bot.id, `Script error on "${text.slice(0, 50)}": ${m}`);
      }
    }
  });

  client.on(Events.Error, async (err) => {
    logger.error({ err, botId: bot.id }, "discord client error");
    await appendLog(bot.id, `ERROR: ${err.message}`);
  });

  try {
    await client.login(bot.token);
    runningBots.set(bot.id, { client, startedAt: new Date(), scriptHandler });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    await appendLog(bot.id, `Failed to start: ${message}`);
    await db
      .update(bots)
      .set({ status: "error", lastError: message, updatedAt: new Date() })
      .where(eq(bots.id, bot.id));
    throw e;
  }
}

export async function stopBot(botId: string): Promise<void> {
  const running = runningBots.get(botId);
  if (running) {
    try {
      await running.client.destroy();
    } catch {
      // ignore
    }
    runningBots.delete(botId);
  }
  await appendLog(botId, "Stopped");
  await db
    .update(bots)
    .set({ status: "stopped", updatedAt: new Date() })
    .where(eq(bots.id, botId));
}

// Boot all autoStart bots when the server starts (24/7 mode).
export async function bootAutoStartBots(): Promise<void> {
  try {
    const all = await db.select().from(bots).where(eq(bots.autoStart, true));
    if (!all.length) return;
    logger.info({ count: all.length }, "Booting auto-start bots (24/7 mode)");
    for (const b of all) {
      try {
        await startBot(b);
      } catch (e) {
        const m = e instanceof Error ? e.message : String(e);
        logger.warn({ botId: b.id, err: m }, "Failed to auto-start bot");
      }
    }
  } catch (e) {
    logger.error({ err: e }, "bootAutoStartBots failed");
  }
}
