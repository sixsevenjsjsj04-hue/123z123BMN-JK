import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { Request, Response, NextFunction } from "express";
import { eq, and, gt } from "drizzle-orm";
import { db, users, sessions, type User } from "@workspace/db";

const SESSION_COOKIE = "gs_sid";
const SESSION_TTL_DAYS = 30;

export function hashPassword(plain: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(plain, salt, 64).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(plain: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt, hex] = parts;
  const derived = scryptSync(plain, salt, 64);
  const expected = Buffer.from(hex, "hex");
  if (derived.length !== expected.length) return false;
  return timingSafeEqual(derived, expected);
}

export async function createSession(userId: string): Promise<{ id: string; expiresAt: Date }> {
  const id = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id, userId, expiresAt });
  return { id, expiresAt };
}

export function setSessionCookie(res: Response, id: string, expiresAt: Date): void {
  const isProd = process.env.NODE_ENV === "production";
  const crossSite = process.env.COOKIE_CROSS_SITE === "1";
  res.cookie(SESSION_COOKIE, id, {
    httpOnly: true,
    sameSite: crossSite ? "none" : "lax",
    secure: isProd || crossSite,
    expires: expiresAt,
    path: "/",
  });
}

export function clearSessionCookie(res: Response): void {
  const crossSite = process.env.COOKIE_CROSS_SITE === "1";
  res.clearCookie(SESSION_COOKIE, {
    path: "/",
    sameSite: crossSite ? "none" : "lax",
    secure: process.env.NODE_ENV === "production" || crossSite,
  });
}

export async function destroySession(id: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.id, id));
}

export async function getUserFromRequest(req: Request): Promise<User | null> {
  const sid = req.cookies?.[SESSION_COOKIE];
  if (!sid) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, sid), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return rows[0]?.user ?? null;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const user = await getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ message: "Not authenticated" });
    return;
  }
  if (!user.emailVerified) {
    res.status(403).json({ message: "Email not verified" });
    return;
  }
  req.user = user;
  next();
}

export function publicUser(u: User): {
  id: string;
  email: string;
  displayName: string;
  isOwner: boolean;
  emailVerified: boolean;
} {
  return {
    id: u.id,
    email: u.email,
    displayName: u.displayName,
    isOwner: u.isOwner,
    emailVerified: u.emailVerified,
  };
}
