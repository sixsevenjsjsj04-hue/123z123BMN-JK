import JSZip from "jszip";
import { eq } from "drizzle-orm";
import { db, files, messages, type FileRow, type MessageAttachment } from "@workspace/db";

// AI is instructed to wrap generated files in tags like:
// <gs:file path="src/main.py" mime="text/x-python">
// ...content...
// </gs:file>
// And ZIPs:
// <gs:zip name="bot.zip">
//   <gs:file path="index.js" mime="application/javascript">...</gs:file>
//   <gs:file path="package.json" mime="application/json">...</gs:file>
// </gs:zip>

export type ParsedFile = {
  path: string;
  mimeType: string;
  content: string;
};

export type ParsedZip = {
  name: string;
  entries: ParsedFile[];
};

export type ParsedAiOutput = {
  cleanText: string;
  files: ParsedFile[];
  zips: ParsedZip[];
};

const FILE_RE =
  /<gs:file\s+path="([^"]+)"(?:\s+mime="([^"]+)")?\s*>([\s\S]*?)<\/gs:file>/g;

const ZIP_RE =
  /<gs:zip\s+name="([^"]+)"\s*>([\s\S]*?)<\/gs:zip>/g;

function inferMime(path: string, fallback?: string): string {
  if (fallback) return fallback;
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  switch (ext) {
    case "py":
      return "text/x-python";
    case "js":
    case "mjs":
    case "cjs":
      return "application/javascript";
    case "ts":
    case "tsx":
      return "application/typescript";
    case "json":
      return "application/json";
    case "html":
      return "text/html";
    case "css":
      return "text/css";
    case "md":
      return "text/markdown";
    case "lua":
    case "luau":
      return "text/x-lua";
    case "txt":
      return "text/plain";
    case "yml":
    case "yaml":
      return "text/yaml";
    case "sh":
      return "application/x-sh";
    default:
      return "text/plain";
  }
}

export function parseAiOutput(raw: string): ParsedAiOutput {
  const zips: ParsedZip[] = [];
  const standaloneFiles: ParsedFile[] = [];
  let working = raw;

  // Extract zips first (so files inside zips don't double-count).
  working = working.replace(ZIP_RE, (_, name: string, inner: string) => {
    const entries: ParsedFile[] = [];
    let m: RegExpExecArray | null;
    const re = new RegExp(FILE_RE.source, "g");
    while ((m = re.exec(inner)) !== null) {
      const [, path, mime, content] = m;
      entries.push({
        path: path.trim(),
        mimeType: inferMime(path, mime),
        content: content.replace(/^\n/, "").replace(/\n$/, ""),
      });
    }
    zips.push({ name: name.trim(), entries });
    return ""; // strip from clean text
  });

  // Now extract standalone files.
  working = working.replace(FILE_RE, (_, path: string, mime: string | undefined, content: string) => {
    standaloneFiles.push({
      path: path.trim(),
      mimeType: inferMime(path, mime),
      content: content.replace(/^\n/, "").replace(/\n$/, ""),
    });
    return "";
  });

  return {
    cleanText: working.trim(),
    files: standaloneFiles,
    zips,
  };
}

export async function persistGeneratedArtifacts(args: {
  userId: string;
  conversationId: string;
  output: ParsedAiOutput;
}): Promise<string[]> {
  const ids: string[] = [];

  for (const f of args.output.files) {
    const folder = "/" + (f.path.includes("/") ? f.path.slice(0, f.path.lastIndexOf("/")).replace(/^\//, "") : "");
    const name = f.path.split("/").pop() || f.path;
    const [row] = await db
      .insert(files)
      .values({
        userId: args.userId,
        conversationId: args.conversationId,
        name,
        folder: folder || "/",
        mimeType: f.mimeType,
        size: Buffer.byteLength(f.content, "utf8"),
        source: "ai_generated",
        content: f.content,
      })
      .returning();
    ids.push(row.id);
  }

  for (const zip of args.output.zips) {
    const jz = new JSZip();
    for (const e of zip.entries) {
      jz.file(e.path, e.content);
    }
    const buffer = await jz.generateAsync({ type: "nodebuffer" });
    const dataB64 = buffer.toString("base64");
    const [row] = await db
      .insert(files)
      .values({
        userId: args.userId,
        conversationId: args.conversationId,
        name: zip.name,
        folder: "/",
        mimeType: "application/zip",
        size: buffer.length,
        source: "ai_generated",
        dataB64,
      })
      .returning();
    ids.push(row.id);
  }

  return ids;
}

// Anthropic image content blocks support these mediatypes.
const SUPPORTED_IMAGE_MEDIA = new Set([
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
]);

export type AiUserContentBlock =
  | { type: "text"; text: string }
  | {
      type: "image";
      source: { type: "base64"; media_type: string; data: string };
    };

export async function loadAttachmentsForAi(
  userId: string,
  fileIds: string[],
): Promise<{
  attachments: MessageAttachment[];
  textPreamble: string;
  imageBlocks: AiUserContentBlock[];
}> {
  if (fileIds.length === 0) return { attachments: [], textPreamble: "", imageBlocks: [] };
  const rows: FileRow[] = [];
  for (const id of fileIds) {
    const [r] = await db.select().from(files).where(eq(files.id, id)).limit(1);
    if (r && r.userId === userId) rows.push(r);
  }
  const attachments: MessageAttachment[] = rows.map((r) => ({
    fileId: r.id,
    name: r.name,
    mimeType: r.mimeType,
    size: r.size,
  }));

  const textSegments: string[] = [];
  const imageBlocks: AiUserContentBlock[] = [];

  for (const r of rows) {
    const isArchive =
      r.mimeType.includes("zip") ||
      r.mimeType.includes("tar") ||
      r.mimeType.includes("gzip") ||
      /\.(zip|tar|tar\.gz|tgz|tar\.bz2)$/i.test(r.name);
    if (r.mimeType.startsWith("image/") && r.dataB64) {
      const media = SUPPORTED_IMAGE_MEDIA.has(r.mimeType) ? r.mimeType : "image/png";
      imageBlocks.push({
        type: "image",
        source: { type: "base64", media_type: media, data: r.dataB64 },
      });
      textSegments.push(
        `Image attached (fileId=${r.id}): ${r.name} (${r.mimeType}). Inspect it carefully — read any visible text, describe layout, identify code/UI/diagrams, and use what you see when answering.`,
      );
    } else if (isArchive) {
      textSegments.push(
        `Archive attached (fileId=${r.id}): ${r.name} (${r.mimeType}, ${r.size} bytes). Call extract_archive with this fileId to read the contents BEFORE answering.`,
      );
    } else if (r.content) {
      textSegments.push(
        `File (fileId=${r.id}): ${r.name} (${r.mimeType})\n\`\`\`\n${r.content}\n\`\`\``,
      );
    } else if (r.dataB64) {
      textSegments.push(
        `Binary file (fileId=${r.id}): ${r.name} (${r.mimeType}, ${r.size} bytes) — contents are binary and not shown.`,
      );
    }
  }
  const textPreamble = textSegments.length
    ? `The user attached the following files. Treat them as authoritative context:\n\n${textSegments.join("\n\n")}\n\n`
    : "";
  return { attachments, textPreamble, imageBlocks };
}

export async function persistUserMessage(args: {
  conversationId: string;
  content: string;
  attachments: MessageAttachment[];
}): Promise<{ id: string; createdAt: Date }> {
  const [row] = await db
    .insert(messages)
    .values({
      conversationId: args.conversationId,
      role: "user",
      content: args.content,
      attachments: args.attachments,
      generatedFileIds: [],
    })
    .returning();
  return { id: row.id, createdAt: row.createdAt };
}

export async function persistAssistantMessage(args: {
  conversationId: string;
  content: string;
  thinking: string | null;
  generatedFileIds: string[];
}): Promise<{ id: string; createdAt: Date }> {
  const [row] = await db
    .insert(messages)
    .values({
      conversationId: args.conversationId,
      role: "assistant",
      content: args.content,
      thinking: args.thinking,
      attachments: [],
      generatedFileIds: args.generatedFileIds,
    })
    .returning();
  return { id: row.id, createdAt: row.createdAt };
}
