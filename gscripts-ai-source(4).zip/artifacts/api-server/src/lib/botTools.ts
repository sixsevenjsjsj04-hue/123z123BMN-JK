import { and, eq } from "drizzle-orm";
import { db, bots, files, type Bot } from "@workspace/db";
import { isBotRunning, startBot, stopBot, getRecentBotMessages } from "./botManager";
import { extractArchiveFromFile, type ExtractedEntry } from "./archive";

export type BotToolName =
  | "list_bots"
  | "get_bot"
  | "create_bot"
  | "update_bot"
  | "start_bot"
  | "stop_bot"
  | "delete_bot"
  | "tail_bot_log"
  | "set_bot_script"
  | "set_bot_autostart"
  | "list_bot_messages"
  | "validate_bot_script"
  | "extract_archive";

export const BOT_TOOLS = [
  {
    name: "list_bots",
    description:
      "List every bot the current user has registered, with id, name, status, autoStart flag, and a short log preview. Use this first when the user asks anything about their bots.",
    input_schema: { type: "object" as const, properties: {} },
  },
  {
    name: "get_bot",
    description:
      "Get the full record for one bot (including the latest log buffer, last error, and current custom script if any). Use after list_bots when you need details.",
    input_schema: {
      type: "object" as const,
      properties: { id: { type: "string" } },
      required: ["id"],
    },
  },
  {
    name: "create_bot",
    description:
      "Create a new Discord bot launcher with the supplied token. Returns the new bot id. Token is stored privately and is never shown back to the user. Only call this when the user has clearly given a token to add.",
    input_schema: {
      type: "object" as const,
      properties: {
        name: { type: "string" },
        token: { type: "string" },
      },
      required: ["name", "token"],
    },
  },
  {
    name: "update_bot",
    description:
      "Rename a bot or replace its Discord token. Pass any subset of name/token. Stops the bot first if it is currently running.",
    input_schema: {
      type: "object" as const,
      properties: {
        id: { type: "string" },
        name: { type: "string" },
        token: { type: "string" },
      },
      required: ["id"],
    },
  },
  {
    name: "start_bot",
    description: "Launch the bot. The bot's status will become 'running' on success.",
    input_schema: {
      type: "object" as const,
      properties: { id: { type: "string" } },
      required: ["id"],
    },
  },
  {
    name: "stop_bot",
    description: "Shut the bot down. Status becomes 'stopped'.",
    input_schema: {
      type: "object" as const,
      properties: { id: { type: "string" } },
      required: ["id"],
    },
  },
  {
    name: "delete_bot",
    description: "Permanently delete the bot. Stops it first if running.",
    input_schema: {
      type: "object" as const,
      properties: { id: { type: "string" } },
      required: ["id"],
    },
  },
  {
    name: "tail_bot_log",
    description:
      "Fetch the latest N characters of the bot's runtime log. Useful after start_bot to see if it actually came online.",
    input_schema: {
      type: "object" as const,
      properties: {
        id: { type: "string" },
        chars: { type: "number" },
      },
      required: ["id"],
    },
  },
  {
    name: "set_bot_script",
    description: `Install a custom JavaScript handler that runs for every Discord message the bot receives. The script body has access to:
- ctx.message: { content, authorId, authorTag, channelId, guildId, isBot }
- ctx.reply(text): reply to the triggering message
- ctx.send(channelId, text): send to a channel
- ctx.log(line): write to bot log
Available globals: console, fetch, setTimeout, setInterval, JSON, Math, Date, Buffer, URL.
The script restarts on the next bot start. After calling this, restart the bot for the change to take effect. Always validate_bot_script first.`,
    input_schema: {
      type: "object" as const,
      properties: {
        id: { type: "string" },
        script: { type: "string" },
      },
      required: ["id", "script"],
    },
  },
  {
    name: "validate_bot_script",
    description:
      "Compile-check a candidate bot script WITHOUT installing it. Returns { ok: true } or { ok: false, error: '...' }. Always run this before set_bot_script and after any AI-authored fix.",
    input_schema: {
      type: "object" as const,
      properties: { script: { type: "string" } },
      required: ["script"],
    },
  },
  {
    name: "set_bot_autostart",
    description:
      "Enable or disable 24/7 mode. When enabled, the bot starts automatically every time the API server boots and runs even if the user closes their browser.",
    input_schema: {
      type: "object" as const,
      properties: {
        id: { type: "string" },
        enabled: { type: "boolean" },
      },
      required: ["id", "enabled"],
    },
  },
  {
    name: "list_bot_messages",
    description:
      "Return the last messages this bot has SENT in Discord since it last started. Lets you verify what the bot actually said.",
    input_schema: {
      type: "object" as const,
      properties: {
        id: { type: "string" },
        limit: { type: "number" },
      },
      required: ["id"],
    },
  },
  {
    name: "extract_archive",
    description:
      "Extract a previously uploaded archive file (.zip, .tar, .tar.gz, .tgz) by its file id. Returns a list of extracted entries with their path, size, and (for text files) the first chunk of content. Use this after the user uploads a project archive so you can read its contents.",
    input_schema: {
      type: "object" as const,
      properties: {
        fileId: { type: "string" },
        maxEntries: { type: "number" },
        maxBytesPerEntry: { type: "number" },
      },
      required: ["fileId"],
    },
  },
] as const;

function summarize(b: Bot) {
  return {
    id: b.id,
    name: b.name,
    platform: b.platform,
    status: b.status,
    lastError: b.lastError,
    autoStart: b.autoStart,
    hasScript: Boolean(b.script && b.script.trim()),
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt.toISOString(),
    logTail: b.log ? b.log.slice(-400) : "",
    isRunning: isBotRunning(b.id),
  };
}

async function findBot(userId: string, id: string): Promise<Bot | null> {
  const [row] = await db
    .select()
    .from(bots)
    .where(and(eq(bots.id, id), eq(bots.userId, userId)))
    .limit(1);
  return row ?? null;
}

function compileCheck(code: string): { ok: true } | { ok: false; error: string } {
  try {
    // Wrap exactly the way the runtime does so the error position is meaningful.
    // Use Function (no execution) to surface SyntaxError without running it.
    new Function("ctx", `return (async () => { ${code}\n})()`);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function executeBotTool(
  userId: string,
  name: string,
  input: Record<string, unknown>,
): Promise<unknown> {
  switch (name as BotToolName) {
    case "list_bots": {
      const rows = await db.select().from(bots).where(eq(bots.userId, userId));
      return { bots: rows.map(summarize) };
    }
    case "get_bot": {
      const id = String(input.id);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      return {
        bot: {
          ...summarize(row),
          log: row.log ?? "",
          script: row.script ?? "",
        },
      };
    }
    case "create_bot": {
      const name = String(input.name ?? "").trim();
      const token = String(input.token ?? "").trim();
      if (!name || !token) return { error: "name and token are required" };
      const [row] = await db
        .insert(bots)
        .values({
          userId,
          name,
          token,
          platform: "discord",
          status: "stopped",
          log: "",
        })
        .returning();
      return { ok: true, bot: summarize(row) };
    }
    case "update_bot": {
      const id = String(input.id);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      if (isBotRunning(id)) await stopBot(id);
      const patch: Partial<Bot> = { updatedAt: new Date() };
      if (typeof input.name === "string" && input.name.trim()) patch.name = input.name.trim();
      if (typeof input.token === "string" && input.token.trim()) patch.token = input.token.trim();
      await db.update(bots).set(patch).where(eq(bots.id, id));
      const [updated] = await db.select().from(bots).where(eq(bots.id, id)).limit(1);
      return { ok: true, bot: summarize(updated) };
    }
    case "start_bot": {
      const id = String(input.id);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      try {
        await startBot(row);
      } catch (e) {
        return { error: e instanceof Error ? e.message : String(e) };
      }
      await new Promise((r) => setTimeout(r, 1500));
      const [refreshed] = await db.select().from(bots).where(eq(bots.id, id)).limit(1);
      return { ok: true, bot: summarize(refreshed) };
    }
    case "stop_bot": {
      const id = String(input.id);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      await stopBot(id);
      const [refreshed] = await db.select().from(bots).where(eq(bots.id, id)).limit(1);
      return { ok: true, bot: summarize(refreshed) };
    }
    case "delete_bot": {
      const id = String(input.id);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      if (isBotRunning(id)) await stopBot(id);
      await db.delete(bots).where(eq(bots.id, id));
      return { ok: true };
    }
    case "tail_bot_log": {
      const id = String(input.id);
      const chars = Math.max(50, Math.min(8000, Number(input.chars) || 1500));
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      const log = row.log ?? "";
      return { tail: log.slice(-chars), totalChars: log.length, status: row.status };
    }
    case "validate_bot_script": {
      const script = String(input.script ?? "");
      return compileCheck(script);
    }
    case "set_bot_script": {
      const id = String(input.id);
      const script = String(input.script ?? "");
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      const check = compileCheck(script);
      if (!check.ok) return { error: `Script failed compile-check: ${check.error}` };
      await db.update(bots).set({ script, updatedAt: new Date() }).where(eq(bots.id, id));
      return {
        ok: true,
        note: "Script saved. Restart the bot (start_bot) for it to take effect.",
      };
    }
    case "set_bot_autostart": {
      const id = String(input.id);
      const enabled = Boolean(input.enabled);
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      await db.update(bots).set({ autoStart: enabled, updatedAt: new Date() }).where(eq(bots.id, id));
      return { ok: true, autoStart: enabled };
    }
    case "list_bot_messages": {
      const id = String(input.id);
      const limit = Math.max(1, Math.min(200, Number(input.limit) || 50));
      const row = await findBot(userId, id);
      if (!row) return { error: "Bot not found" };
      return { messages: getRecentBotMessages(id, limit) };
    }
    case "extract_archive": {
      const fileId = String(input.fileId);
      const maxEntries = Math.max(1, Math.min(2000, Number(input.maxEntries) || 200));
      const maxBytes = Math.max(256, Math.min(200_000, Number(input.maxBytesPerEntry) || 4000));
      const [f] = await db
        .select()
        .from(files)
        .where(and(eq(files.id, fileId), eq(files.userId, userId)))
        .limit(1);
      if (!f) return { error: "File not found" };
      try {
        const entries: ExtractedEntry[] = await extractArchiveFromFile(f, {
          maxEntries,
          maxBytesPerEntry: maxBytes,
        });
        return {
          ok: true,
          archive: f.name,
          entryCount: entries.length,
          entries,
        };
      } catch (e) {
        return { error: e instanceof Error ? e.message : String(e) };
      }
    }
    default:
      return { error: `Unknown tool: ${name}` };
  }
}
