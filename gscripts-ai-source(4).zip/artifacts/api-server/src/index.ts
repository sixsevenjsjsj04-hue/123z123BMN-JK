import app from "./app";
import { logger } from "./lib/logger";
import { bootAutoStartBots } from "./lib/botManager";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // 24/7 mode: bring up any bots flagged for auto-start.
  bootAutoStartBots().catch((e) => {
    logger.error({ err: e }, "bootAutoStartBots threw");
  });
});
