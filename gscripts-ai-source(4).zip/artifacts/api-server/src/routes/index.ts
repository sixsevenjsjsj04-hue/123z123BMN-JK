import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import chatRouter from "./chat";
import filesRouter from "./files";
import botsRouter from "./bots";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(chatRouter);
router.use(filesRouter);
router.use(botsRouter);

export default router;
