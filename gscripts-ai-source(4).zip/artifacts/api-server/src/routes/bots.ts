import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, bots, type Bot } from "@workspace/db";
import { CreateBotBody } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { startBot, stopBot } from "../lib/botManager";

const router: IRouter = Router();

router.use(requireAuth);

function publicBot(b: Bot) {
  return {
    id: b.id,
    name: b.name,
    platform: b.platform,
    status: b.status,
    lastError: b.lastError,
    log: b.log,
    createdAt: b.createdAt.toISOString(),
    updatedAt: b.updatedAt.toISOString(),
  };
}

router.get("/bots", async (req, res) => {
  const rows = await db
    .select()
    .from(bots)
    .where(eq(bots.userId, req.user!.id))
    .orderBy(desc(bots.updatedAt));
  res.json(rows.map(publicBot));
});

router.post("/bots", async (req, res) => {
  const parsed = CreateBotBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid bot payload" });
    return;
  }
  const [row] = await db
    .insert(bots)
    .values({
      userId: req.user!.id,
      name: parsed.data.name,
      platform: "discord",
      token: parsed.data.token,
      status: "stopped",
    })
    .returning();
  res.json(publicBot(row));
});

router.delete("/bots/:id", async (req, res) => {
  const id = req.params.id;
  try {
    await stopBot(id);
  } catch {
    // ignore
  }
  await db.delete(bots).where(and(eq(bots.id, id), eq(bots.userId, req.user!.id)));
  res.json({ ok: true });
});

router.post("/bots/:id/start", async (req, res) => {
  const [row] = await db
    .select()
    .from(bots)
    .where(and(eq(bots.id, req.params.id), eq(bots.userId, req.user!.id)))
    .limit(1);
  if (!row) {
    res.status(404).json({ message: "Bot not found" });
    return;
  }
  try {
    await startBot(row);
    const [refreshed] = await db.select().from(bots).where(eq(bots.id, row.id)).limit(1);
    res.json(publicBot(refreshed!));
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    res.status(400).json({ message: `Failed to start bot: ${message}` });
  }
});

router.post("/bots/:id/stop", async (req, res) => {
  const [row] = await db
    .select()
    .from(bots)
    .where(and(eq(bots.id, req.params.id), eq(bots.userId, req.user!.id)))
    .limit(1);
  if (!row) {
    res.status(404).json({ message: "Bot not found" });
    return;
  }
  await stopBot(row.id);
  const [refreshed] = await db.select().from(bots).where(eq(bots.id, row.id)).limit(1);
  res.json(publicBot(refreshed!));
});

export default router;
