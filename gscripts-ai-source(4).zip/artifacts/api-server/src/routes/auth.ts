import { Router, type IRouter } from "express";
import { eq, and, gt } from "drizzle-orm";
import { db, users, verificationCodes } from "@workspace/db";
import { SignupBody, VerifyEmailBody, LoginBody } from "@workspace/api-zod";
import {
  hashPassword,
  verifyPassword,
  createSession,
  setSessionCookie,
  clearSessionCookie,
  destroySession,
  getUserFromRequest,
  publicUser,
} from "../lib/auth";
import { verifyTurnstile, getTurnstileSiteKey } from "../lib/turnstile";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const isProd = process.env.NODE_ENV === "production";

function generateCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

router.get("/auth/turnstile-config", (_req, res) => {
  res.json({ siteKey: getTurnstileSiteKey() });
});

router.post("/auth/signup", async (req, res) => {
  const parsed = SignupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid signup payload" });
    return;
  }
  const { email, password, displayName, turnstileToken } = parsed.data;

  const ok = await verifyTurnstile(turnstileToken, req.ip);
  if (!ok) {
    res.status(400).json({ message: "Verification failed. Please try again." });
    return;
  }

  const normalizedEmail = email.toLowerCase().trim();
  const [existing] = await db
    .select()
    .from(users)
    .where(eq(users.email, normalizedEmail))
    .limit(1);
  if (existing && existing.emailVerified) {
    res.status(409).json({ message: "An account with that email already exists." });
    return;
  }

  const passwordHash = hashPassword(password);
  if (existing) {
    await db
      .update(users)
      .set({ passwordHash, displayName })
      .where(eq(users.id, existing.id));
  } else {
    await db.insert(users).values({
      email: normalizedEmail,
      passwordHash,
      displayName,
    });
  }

  const code = generateCode();
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await db.insert(verificationCodes).values({
    email: normalizedEmail,
    code,
    purpose: "signup",
    expiresAt,
  });

  logger.info({ email: normalizedEmail }, "Verification code issued");

  res.json({
    email: normalizedEmail,
    devCode: isProd ? "" : code,
  });
});

router.post("/auth/verify", async (req, res) => {
  const parsed = VerifyEmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid verification payload" });
    return;
  }
  const email = parsed.data.email.toLowerCase().trim();
  const code = parsed.data.code.trim();

  const [vc] = await db
    .select()
    .from(verificationCodes)
    .where(
      and(
        eq(verificationCodes.email, email),
        eq(verificationCodes.code, code),
        eq(verificationCodes.used, false),
        gt(verificationCodes.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (!vc) {
    res.status(400).json({ message: "Code is invalid or expired." });
    return;
  }

  await db
    .update(verificationCodes)
    .set({ used: true })
    .where(eq(verificationCodes.id, vc.id));

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) {
    res.status(404).json({ message: "Account not found." });
    return;
  }

  if (!user.emailVerified) {
    await db.update(users).set({ emailVerified: true }).where(eq(users.id, user.id));
    user.emailVerified = true;
  }

  const session = await createSession(user.id);
  setSessionCookie(res, session.id, session.expiresAt);
  res.json({ user: publicUser(user) });
});

router.post("/auth/login", async (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid login payload" });
    return;
  }
  const { email, password, turnstileToken } = parsed.data;

  const ok = await verifyTurnstile(turnstileToken, req.ip);
  if (!ok) {
    res.status(400).json({ message: "Verification failed. Please try again." });
    return;
  }

  const normalized = email.toLowerCase().trim();
  const [user] = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    res.status(401).json({ message: "Email or password is incorrect." });
    return;
  }
  if (!user.emailVerified) {
    res.status(403).json({ message: "Please verify your email first." });
    return;
  }

  const session = await createSession(user.id);
  setSessionCookie(res, session.id, session.expiresAt);
  res.json({ user: publicUser(user) });
});

router.post("/auth/logout", async (req, res) => {
  const sid = req.cookies?.["gs_sid"];
  if (sid) {
    try {
      await destroySession(sid);
    } catch {
      // ignore
    }
  }
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get("/auth/me", async (req, res) => {
  const user = await getUserFromRequest(req);
  res.json({ user: user ? publicUser(user) : null });
});

export default router;
