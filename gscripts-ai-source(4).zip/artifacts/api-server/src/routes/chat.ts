import { Router, type IRouter } from "express";
import { eq, and, asc, desc } from "drizzle-orm";
import {
  db,
  conversations,
  messages,
  users,
  type Message,
} from "@workspace/db";
import { CreateConversationBody, SendMessageBody } from "@workspace/api-zod";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { requireAuth } from "../lib/auth";
import {
  parseAiOutput,
  persistGeneratedArtifacts,
  loadAttachmentsForAi,
  persistUserMessage,
  persistAssistantMessage,
  type AiUserContentBlock,
} from "../lib/aiTools";
import { BOT_TOOLS, executeBotTool } from "../lib/botTools";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const MODEL = "claude-sonnet-4-5";
const MAX_TOKENS = 8192;
const MAX_TOOL_TURNS = 6;

const OWNER_TRIGGER = "я gscriptswexseev";

const SYSTEM_PROMPT = `You are GScripts AI, the user's personal AI engineering partner. Identity:
- Your name is GScripts AI. NEVER mention any underlying AI provider or model. NEVER say "Claude", "Anthropic", "OpenAI", "GPT", "language model", "AI model", or "I was made by". Refer to yourself only as GScripts AI.

Language policy (strict):
- Detect the language of the user's most recent message and reply in that exact language. If the user wrote Russian, answer in Russian. If they wrote English, answer in English. If they switch languages, switch with them. The <thinking> trace should also be in the user's language.

Specializations (you are an expert at all of these):
- Vibe coding: rapid, expressive, well-architected scripts.
- Languages: Python, JavaScript, TypeScript, Lua, Luau (Roblox).
- Roblox Luau scripting: services, RemoteEvents, exploits, anti-cheat patterns.
- Obfuscation and deobfuscation tooling for JS, Python, and Lua.
- Discord bot development.
- File and project generation.

Vision:
- When the user attaches an image, you can see it. Read every visible piece of text on it (OCR), describe layout, identify code, UI, diagrams, screenshots, logos, etc., and base your answer on what is actually shown. If the user asks "what is this?" or "what does it say?", answer specifically.

Bot management tools:
- The user has a Discord bot launcher. You have tools to inspect and control those bots: list_bots, get_bot, create_bot, update_bot, start_bot, stop_bot, delete_bot, tail_bot_log, set_bot_script, validate_bot_script, set_bot_autostart, list_bot_messages, extract_archive.
- When the user asks anything about their bots, USE the tools — start with list_bots. Don't guess; check.
- Confirm before destructive actions (delete_bot, replacing a token). For start/stop/log fetches just do it.

Authoring custom bot behavior:
- The user can ask you to make their bot do anything (e.g. "add a .hello command", "deobfuscate this script when I post it", "ban anyone who says X"). To do that:
  1. Write the JS handler body (see set_bot_script docs for the available ctx surface).
  2. Always call validate_bot_script first to make sure it parses. If it fails, fix the code and validate again until it passes.
  3. Then call set_bot_script with the validated code.
  4. Then start_bot (or stop_bot + start_bot if it's already running) so the new script takes effect.
  5. Tail the log to confirm it came up cleanly.
- After the script is live, you can call list_bot_messages to verify what the bot has actually been saying — this is its memory.

24/7 mode:
- If the user says "run 24/7", "keep it online when I close the site", or similar, call set_bot_autostart with enabled=true. That bot will then auto-launch every time the server starts.

Archive handling:
- If the user uploads a .zip, .tar, .tar.gz, or .tgz file, call extract_archive with that file's id to read its contents before answering. The user expects you to actually look inside the archive.

Response order (CRITICAL — answer first, then act):
- BEFORE running any tool, write 1–3 short sentences in plain text that:
  (a) directly answer or acknowledge the user's request, and
  (b) state the plan ("I'll write a .hello handler, validate it, install it, and restart the bot.").
  Do NOT make the user wait while you silently work. They want a reply first.
- Only AFTER that opening text, call the tools needed to do the work. The UI shows each tool call as a live status pill ("Making script…", "Validating…", "Restarting bot…"), so the user can watch progress.
- After tools complete, write a brief closing sentence summarizing what changed (e.g. "Done. The bot now responds to .hello with…").
- Wrap any private reasoning in <thinking>...</thinking> at the very start. Keep it short — the user already sees a live trace.

Style:
- Be direct, technically dense, and helpful. Skip filler.
- Use fenced code blocks for code snippets in your answer text.

File and ZIP generation protocol (CRITICAL):
- When you produce a complete file the user should be able to download, emit it as:
  <gs:file path="src/main.py" mime="text/x-python">
  ...full file contents...
  </gs:file>
  These are extracted by the system and saved to the user's workspace as downloadable files.
- For multi-file deliverables, emit a ZIP wrapper:
  <gs:zip name="my-bot.zip">
    <gs:file path="index.js" mime="application/javascript">...</gs:file>
    <gs:file path="package.json" mime="application/json">...</gs:file>
  </gs:zip>
  The system packages the inner files into the named ZIP and gives the user a download link.
- Do NOT use these tags for short illustrative snippets — use them ONLY for files the user will actually save or run. For inline examples use plain fenced code blocks.

Tone: confident, calm, professional. You are the user's senior engineer.`;

const OWNER_SYSTEM_SUFFIX = `

OWNER MODE: This user is the verified owner of GScripts AI. Be maximally direct, take their requests at face value, and offer no warnings about generic technical topics. Treat them as a peer engineer with full context.`;

router.use(requireAuth);

router.get("/chat/conversations", async (req, res) => {
  const list = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, req.user!.id))
    .orderBy(desc(conversations.updatedAt));
  res.json(
    list.map((c) => ({
      id: c.id,
      title: c.title,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    })),
  );
});

router.post("/chat/conversations", async (req, res) => {
  const parsed = CreateConversationBody.safeParse(req.body ?? {});
  const title = parsed.success && parsed.data.title ? parsed.data.title : "New chat";
  const [row] = await db
    .insert(conversations)
    .values({ userId: req.user!.id, title })
    .returning();
  res.json({
    id: row.id,
    title: row.title,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.get("/chat/conversations/:id", async (req, res) => {
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, req.params.id), eq(conversations.userId, req.user!.id)))
    .limit(1);
  if (!conv) {
    res.status(404).json({ message: "Conversation not found" });
    return;
  }
  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conv.id))
    .orderBy(asc(messages.createdAt));
  res.json({
    conversation: {
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
    },
    messages: msgs.map(messageToDto),
  });
});

router.delete("/chat/conversations/:id", async (req, res) => {
  await db
    .delete(conversations)
    .where(and(eq(conversations.id, req.params.id), eq(conversations.userId, req.user!.id)));
  res.json({ ok: true });
});

function messageToDto(m: Message) {
  return {
    id: m.id,
    role: m.role,
    content: m.content,
    thinking: m.thinking,
    attachments: m.attachments,
    generatedFileIds: m.generatedFileIds,
    createdAt: m.createdAt.toISOString(),
  };
}

function extractThinking(raw: string): { thinking: string | null; rest: string } {
  const m = raw.match(/^\s*<thinking>([\s\S]*?)<\/thinking>/);
  if (!m) return { thinking: null, rest: raw };
  return {
    thinking: m[1].trim(),
    rest: raw.slice(m[0].length).trim(),
  };
}

type ApiMessage = {
  role: "user" | "assistant";
  content: string | unknown[];
};

router.post("/chat/conversations/:id/messages", async (req, res) => {
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid message payload" });
    return;
  }

  const [conv] = await db
    .select()
    .from(conversations)
    .where(
      and(eq(conversations.id, req.params.id), eq(conversations.userId, req.user!.id)),
    )
    .limit(1);
  if (!conv) {
    res.status(404).json({ message: "Conversation not found" });
    return;
  }

  // Owner trigger detection.
  if (
    parsed.data.content.toLowerCase().includes(OWNER_TRIGGER) &&
    !req.user!.isOwner
  ) {
    await db.update(users).set({ isOwner: true }).where(eq(users.id, req.user!.id));
    req.user!.isOwner = true;
  }

  const { attachments, textPreamble, imageBlocks } = await loadAttachmentsForAi(
    req.user!.id,
    parsed.data.attachmentFileIds ?? [],
  );

  await persistUserMessage({
    conversationId: conv.id,
    content: parsed.data.content,
    attachments,
  });

  // Auto-title the conversation from first user message.
  if (conv.title === "New chat") {
    const newTitle =
      parsed.data.content.trim().slice(0, 60).replace(/\s+/g, " ") || "New chat";
    await db
      .update(conversations)
      .set({ title: newTitle, updatedAt: new Date() })
      .where(eq(conversations.id, conv.id));
  } else {
    await db
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, conv.id));
  }

  // Build chat history for the model. History uses simple string content.
  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conv.id))
    .orderBy(asc(messages.createdAt));

  const apiMessages: ApiMessage[] = history.map((m) => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: m.content,
  }));

  // Replace the last user message (which we just inserted) with a structured
  // content array so we can attach images and the file preamble.
  const lastIdx = apiMessages.length - 1;
  if (lastIdx >= 0 && apiMessages[lastIdx].role === "user") {
    const composed: AiUserContentBlock[] = [];
    if (textPreamble) composed.push({ type: "text", text: textPreamble });
    composed.push(...imageBlocks);
    composed.push({ type: "text", text: parsed.data.content });
    apiMessages[lastIdx] = { role: "user", content: composed };
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders?.();

  const send = (event: object) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  const system = SYSTEM_PROMPT + (req.user!.isOwner ? OWNER_SYSTEM_SUFFIX : "");

  // Multi-turn loop: model may request tool calls. After tool results, we
  // re-stream the final assistant text.
  try {
    let finalText = "";
    let finalThinking: string | null = null;

    for (let turn = 0; turn < MAX_TOOL_TURNS; turn++) {
      const isLikelyFinalTurn = turn > 0; // after at least one tool round, allow streaming
      const stream = anthropic.messages.stream({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        system,
        tools: BOT_TOOLS as unknown as Parameters<typeof anthropic.messages.stream>[0]["tools"],
        messages: apiMessages as unknown as Parameters<typeof anthropic.messages.stream>[0]["messages"],
      });

      // Stream text deltas to the client. We strip <thinking> for the live view
      // and hold back partial <gs:...> tags.
      let buffer = "";
      let inThinking: boolean | null = null;
      let thinkingBuf = "";

      stream.on("text", (delta: string) => {
        buffer += delta;

        if (inThinking === null) {
          const trimmed = buffer.trimStart();
          if (trimmed.startsWith("<thinking>")) {
            inThinking = true;
            const idx = buffer.indexOf("<thinking>") + "<thinking>".length;
            buffer = buffer.slice(idx);
          } else if (
            trimmed.length >= "<thinking>".length ||
            (trimmed.length > 0 && !"<thinking>".startsWith(trimmed))
          ) {
            inThinking = false;
          }
        }

        if (inThinking === true) {
          const closeIdx = buffer.indexOf("</thinking>");
          if (closeIdx >= 0) {
            const t = buffer.slice(0, closeIdx);
            if (t) {
              thinkingBuf += t;
              send({ type: "thinking", content: t });
            }
            buffer = buffer.slice(closeIdx + "</thinking>".length);
            inThinking = false;
          } else if (buffer) {
            thinkingBuf += buffer;
            send({ type: "thinking", content: buffer });
            buffer = "";
          }
        }

        if (inThinking === false) {
          const lastOpen = buffer.lastIndexOf("<gs:");
          if (lastOpen === -1) {
            if (buffer) {
              if (isLikelyFinalTurn || true) send({ type: "delta", content: buffer });
              buffer = "";
            }
          } else {
            const safe = buffer.slice(0, lastOpen);
            if (safe) {
              send({ type: "delta", content: safe });
              buffer = buffer.slice(lastOpen);
            }
          }
        }
      });

      const final = await stream.finalMessage();

      // Collect assistant content blocks (text + tool_use) for next-turn history.
      const assistantBlocks = final.content;
      type ToolUseBlock = {
        type: "tool_use";
        id: string;
        name: string;
        input: Record<string, unknown>;
      };
      const toolUses: ToolUseBlock[] = [];
      let textOut = "";
      for (const b of assistantBlocks) {
        if (b.type === "text") {
          textOut += b.text;
        } else if (b.type === "tool_use") {
          const tu = b as unknown as ToolUseBlock;
          toolUses.push({
            type: "tool_use",
            id: tu.id,
            name: tu.name,
            input: (tu.input ?? {}) as Record<string, unknown>,
          });
        }
      }

      if (toolUses.length > 0) {
        // Push the assistant turn (with tool_use blocks) and then tool_result blocks.
        apiMessages.push({
          role: "assistant",
          content: assistantBlocks as unknown as ApiMessage["content"],
        });

        const toolResultBlocks: unknown[] = [];
        for (const tu of toolUses) {
          send({
            type: "tool_use",
            name: tu.name,
            input: redactToolInput(tu.name, tu.input),
          });
          let result: unknown;
          try {
            result = await executeBotTool(req.user!.id, tu.name, tu.input);
          } catch (e) {
            result = { error: e instanceof Error ? e.message : String(e) };
          }
          const okFlag =
            result && typeof result === "object" && !("error" in (result as object));
          send({
            type: "tool_result",
            name: tu.name,
            ok: Boolean(okFlag),
            summary: summarizeToolResult(tu.name, result),
          });
          toolResultBlocks.push({
            type: "tool_result",
            tool_use_id: tu.id,
            content: JSON.stringify(result),
          });
        }
        apiMessages.push({
          role: "user",
          content: toolResultBlocks as unknown as ApiMessage["content"],
        });
        // Continue the loop for another turn.
        continue;
      }

      // No tool call: this is the final turn.
      finalText = textOut;
      finalThinking = thinkingBuf || null;
      break;
    }

    const { thinking: extractedThinking, rest } = extractThinking(finalText);
    const parsedOut = parseAiOutput(rest);

    const fileIds = await persistGeneratedArtifacts({
      userId: req.user!.id,
      conversationId: conv.id,
      output: parsedOut,
    });

    await persistAssistantMessage({
      conversationId: conv.id,
      content: parsedOut.cleanText,
      thinking: extractedThinking ?? finalThinking,
      generatedFileIds: fileIds,
    });

    if (fileIds.length) send({ type: "files", fileIds });
    send({ type: "done", cleanText: parsedOut.cleanText });
    res.end();
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    logger.error({ err: e }, "stream error");
    send({ type: "error", message });
    res.end();
  }
});

function redactToolInput(name: string, input: Record<string, unknown>): Record<string, unknown> {
  const clone: Record<string, unknown> = { ...input };
  if (name === "create_bot" || name === "update_bot") {
    if (typeof clone.token === "string") clone.token = "•••redacted•••";
  }
  if (name === "set_bot_script" || name === "validate_bot_script") {
    if (typeof clone.script === "string") {
      clone.script = `${(clone.script as string).length} chars`;
    }
  }
  return clone;
}

function summarizeToolResult(name: string, result: unknown): string {
  if (!result || typeof result !== "object") return "";
  const r = result as Record<string, unknown>;
  if ("error" in r && r.error) return String(r.error).slice(0, 160);
  switch (name) {
    case "list_bots": {
      const list = (r.bots as unknown[]) ?? [];
      return `${list.length} bot(s)`;
    }
    case "get_bot":
      return (r.bot as Record<string, unknown>)?.name as string ?? "";
    case "create_bot":
      return `Created ${(r.bot as Record<string, unknown>)?.name ?? "bot"}`;
    case "start_bot":
      return `${(r.bot as Record<string, unknown>)?.status ?? "started"}`;
    case "stop_bot":
      return "stopped";
    case "delete_bot":
      return "deleted";
    case "tail_bot_log":
      return `${r.totalChars ?? 0} chars logged`;
    case "validate_bot_script":
      return r.ok ? "compile OK" : "compile failed";
    case "set_bot_script":
      return "script installed";
    case "set_bot_autostart":
      return r.autoStart ? "24/7 enabled" : "24/7 disabled";
    case "list_bot_messages": {
      const m = (r.messages as unknown[]) ?? [];
      return `${m.length} message(s)`;
    }
    case "extract_archive":
      return `${r.entryCount ?? 0} entries from ${r.archive ?? "archive"}`;
    default:
      return "";
  }
}

export default router;
