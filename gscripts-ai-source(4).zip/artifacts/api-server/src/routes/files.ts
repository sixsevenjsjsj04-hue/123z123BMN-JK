import { Router, type IRouter } from "express";
import { eq, and, ilike, or, desc } from "drizzle-orm";
import { db, files } from "@workspace/db";
import { UploadFileBody, UpdateFileBody } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/files", async (req, res) => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const folder = typeof req.query.folder === "string" ? req.query.folder.trim() : "";

  const conditions = [eq(files.userId, req.user!.id)];
  if (q) {
    const like = `%${q}%`;
    const orExpr = or(ilike(files.name, like), ilike(files.content, like));
    if (orExpr) conditions.push(orExpr);
  }
  if (folder) {
    conditions.push(eq(files.folder, folder));
  }

  const rows = await db
    .select({
      id: files.id,
      name: files.name,
      folder: files.folder,
      mimeType: files.mimeType,
      size: files.size,
      source: files.source,
      conversationId: files.conversationId,
      createdAt: files.createdAt,
      updatedAt: files.updatedAt,
    })
    .from(files)
    .where(and(...conditions))
    .orderBy(desc(files.updatedAt));

  res.json(
    rows.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
    })),
  );
});

router.post("/files", async (req, res) => {
  const parsed = UploadFileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid file payload" });
    return;
  }
  const data = parsed.data;
  const folder = data.folder?.trim() || "/";
  const [row] = await db
    .insert(files)
    .values({
      userId: req.user!.id,
      conversationId: data.conversationId ?? null,
      name: data.name,
      folder,
      mimeType: data.mimeType,
      size: data.size,
      source: "user_upload",
      content: data.content ?? null,
      dataB64: data.dataB64 ?? null,
    })
    .returning();
  res.json({
    id: row.id,
    name: row.name,
    folder: row.folder,
    mimeType: row.mimeType,
    size: row.size,
    source: row.source,
    conversationId: row.conversationId,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.get("/files/:id", async (req, res) => {
  const [row] = await db
    .select()
    .from(files)
    .where(and(eq(files.id, req.params.id), eq(files.userId, req.user!.id)))
    .limit(1);
  if (!row) {
    res.status(404).json({ message: "File not found" });
    return;
  }
  res.json({
    id: row.id,
    name: row.name,
    folder: row.folder,
    mimeType: row.mimeType,
    size: row.size,
    source: row.source,
    conversationId: row.conversationId,
    content: row.content,
    dataB64: row.dataB64,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.patch("/files/:id", async (req, res) => {
  const parsed = UpdateFileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid update payload" });
    return;
  }
  const data = parsed.data;
  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (data.name !== undefined) updates.name = data.name;
  if (data.folder !== undefined) updates.folder = data.folder;
  if (data.content !== undefined) {
    updates.content = data.content;
    updates.size = data.content ? Buffer.byteLength(data.content, "utf8") : 0;
  }
  const [row] = await db
    .update(files)
    .set(updates)
    .where(and(eq(files.id, req.params.id), eq(files.userId, req.user!.id)))
    .returning();
  if (!row) {
    res.status(404).json({ message: "File not found" });
    return;
  }
  res.json({
    id: row.id,
    name: row.name,
    folder: row.folder,
    mimeType: row.mimeType,
    size: row.size,
    source: row.source,
    conversationId: row.conversationId,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.delete("/files/:id", async (req, res) => {
  await db
    .delete(files)
    .where(and(eq(files.id, req.params.id), eq(files.userId, req.user!.id)));
  res.json({ ok: true });
});

export default router;
