import { pgTable, text, uuid, timestamp, jsonb } from "drizzle-orm/pg-core";
import { conversations } from "./conversations";

export type MessageAttachment = {
  fileId: string;
  name: string;
  mimeType: string;
  size: number;
};

export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  conversationId: uuid("conversation_id")
    .notNull()
    .references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  thinking: text("thinking"),
  attachments: jsonb("attachments").$type<MessageAttachment[]>().default([]).notNull(),
  generatedFileIds: jsonb("generated_file_ids").$type<string[]>().default([]).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
