import { pgTable, text, uuid, timestamp, integer, varchar } from "drizzle-orm/pg-core";
import { users } from "./users";
import { conversations } from "./conversations";

// Files in the user's workspace. content is the textual content for text-like files,
// dataB64 holds base64-encoded bytes for binary files (zip, images, etc).
export const files = pgTable("files", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  conversationId: uuid("conversation_id").references(() => conversations.id, { onDelete: "set null" }),
  name: varchar("name", { length: 300 }).notNull(),
  folder: varchar("folder", { length: 300 }).notNull().default("/"),
  mimeType: varchar("mime_type", { length: 200 }).notNull().default("text/plain"),
  size: integer("size").notNull().default(0),
  source: varchar("source", { length: 30 }).notNull().default("user_upload"), // user_upload | ai_generated
  content: text("content"), // text content for text-based files
  dataB64: text("data_b64"), // base64 for binary files
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type FileRow = typeof files.$inferSelect;
