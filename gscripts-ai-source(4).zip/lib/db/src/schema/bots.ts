import { pgTable, text, uuid, timestamp, varchar, boolean } from "drizzle-orm/pg-core";
import { users } from "./users";

export const bots = pgTable("bots", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 100 }).notNull(),
  platform: varchar("platform", { length: 30 }).notNull().default("discord"),
  token: text("token").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("stopped"), // stopped | running | error
  lastError: text("last_error"),
  log: text("log").notNull().default(""),
  script: text("script"), // Custom JS handler the AI can author
  autoStart: boolean("auto_start").notNull().default(false), // 24/7 mode — boot on server start
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Bot = typeof bots.$inferSelect;
