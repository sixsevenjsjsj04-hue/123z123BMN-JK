# GScripts AI — деплой

> **TL;DR:** Vercel держит **только фронт**. API-сервер с Discord-ботами поставьте на Replit Deployments / Railway / Fly.io / Render. Postgres — Neon / Supabase / Replit DB. Ниже — пошагово.

---

## 0. Подготовка (один раз)

```bash
npm install -g pnpm
pnpm install
```

В архиве **нет** `node_modules` — это нормально. После `pnpm install` всё появится. (Если `sh` не найден — у вас старая версия архива; в текущей всё кросс-платформенно.)

---

## 1. API-сервер (Discord боты + чат-стрим) → Railway / Replit Deployments / Fly.io

API нельзя ставить на Vercel: serverless рвёт SSE и не держит постоянное Discord-подключение.

### Что нужно задать как переменные окружения:

| Имя | Что это |
| --- | --- |
| `DATABASE_URL` | строка подключения к Postgres (Neon/Supabase) |
| `SESSION_SECRET` | случайная строка ≥ 32 символов |
| `AI_INTEGRATIONS_ANTHROPIC_BASE_URL` | URL Anthropic-совместимого прокси |
| `AI_INTEGRATIONS_ANTHROPIC_API_KEY` | ключ к этому прокси |
| `PORT` | порт (Railway/Fly задают сами) |
| `NODE_ENV` | `production` |
| `COOKIE_CROSS_SITE` | **`1`** — обязательно, если фронт на Vercel, а API на другом домене |
| `TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` | (опционально) реальная капча Cloudflare |

### Команды старта на хостинге:

```bash
# build
pnpm install --frozen-lockfile=false
pnpm --filter @workspace/db run push
pnpm --filter @workspace/api-server run build

# start
pnpm --filter @workspace/api-server run start
```

После запуска у вас будет публичный URL API — например `https://gscripts-api.up.railway.app`. Запомните его.

---

## 2. Фронт → Vercel

### Через сайт vercel.com:

1. Залейте проект на GitHub (целиком, монорепо).
2. На vercel.com → **Add New Project** → выберите репозиторий.
3. **Root Directory** → `artifacts/gscripts-ai-app` (важно!).
4. Vercel сам подхватит `vercel.json` из этой папки — там уже прописаны правильные команды и SPA-роутинг.
5. **Environment Variables** → добавьте:

   | Имя | Значение |
   | --- | --- |
   | `VITE_API_BASE_URL` | URL вашего API из шага 1 (например `https://gscripts-api.up.railway.app`) |

6. Нажмите **Deploy**.

### Через CLI:

```bash
npm i -g vercel
cd artifacts/gscripts-ai-app
vercel --prod
# при первом запуске спросит про настройки — `vercel.json` уже всё указывает
```

---

## 3. Проверьте что всё работает

1. Откройте ваш `*.vercel.app`.
2. Зарегистрируйтесь. Cookie должна установиться (DevTools → Application → Cookies).
3. Залогиньтесь, отправьте сообщение в чат — должен пойти стриминг.

### Если не логинит / пустые ответы:

- Проверьте, что на API задано `COOKIE_CROSS_SITE=1`.
- Проверьте, что API доступен по HTTPS (не HTTP) — без HTTPS браузер не примет `SameSite=None` cookie.
- В DevTools → Network посмотрите, что запросы идут на правильный URL (ваш API, а не на vercel-домен).

---

## Локальная разработка

```bash
# терминал 1 — API
pnpm --filter @workspace/db run push
pnpm --filter @workspace/api-server run dev

# терминал 2 — фронт (по умолчанию слушает 5173)
PORT=5173 pnpm --filter @workspace/gscripts-ai-app run dev
```

В деве `VITE_API_BASE_URL` не задавайте — фронт сходит к API по тому же origin / через прокси.

---

## Структура

- `artifacts/gscripts-ai-app` — React + Vite (статика → Vercel)
- `artifacts/api-server` — Express + Drizzle + Discord.js (живой Node-процесс)
- `lib/db` — схема Postgres (Drizzle)
- `lib/api-client-react` — авто-сгенерированный TypeScript клиент к API
