# GScripts AI

Polished AI engineering co-pilot for vibe coders. Premium dark slate UI with a soft electric-blue accent. The product is presented end-to-end as GScripts AI; no third-party AI vendor branding is shown anywhere in the UI or copy.

## Artifacts
- `artifacts/api-server` — Express + Pino API at `/api/*`. SSE streaming chat, scrypt+session auth, Cloudflare Turnstile, in-memory Discord bot manager with custom-script support and 24/7 auto-boot. Builds to `dist/index.mjs` via esbuild.
- `artifacts/gscripts-ai-app` — React + Vite + Tailwind v4 UI. Wouter routing, TanStack Query, framer-motion, sonner, shadcn/ui kit. Streams chat over fetch + SSE. Supports drag-and-drop and Ctrl+V image paste.
- `artifacts/mockup-sandbox` — design preview server (untouched).

## Backend
- `routes/auth.ts` — signup → email code → verify; login/logout; Turnstile verification; owner trigger phrase `я gscriptswexseev` flips `users.isOwner`.
- `routes/chat.ts` — list/create/get/delete conversations; POST messages streams Server-Sent Events: `{thinking, delta, files, done, error}`. Parses `<thinking>…</thinking>`, `<gs:file name="…">…</gs:file>`, `<gs:zip name="…">[entries]</gs:zip>` from the model output and persists generated files.
- `routes/files.ts` — list (with full-text query `q`), get, upload (text `content` or base64 `dataB64`, 10MB cap), update, delete; `source ∈ {user_upload, ai_generated}`.
- `routes/bots.ts` — list/create/start/stop/delete Discord bots. `lib/botManager.ts` keeps a `Map<botId, Client>`, tails a per-bot log buffer, runs the bot's optional custom JS handler in a `vm` context for every incoming message, and remembers the last 200 outgoing messages per bot in memory. `bootAutoStartBots()` runs on server start and brings up every bot whose `autoStart` is true (24/7 mode).
- `lib/botTools.ts` — Anthropic tool definitions the chat exposes to the model: `list_bots`, `get_bot`, `create_bot`, `update_bot`, `start_bot`, `stop_bot`, `delete_bot`, `tail_bot_log`, `set_bot_script`, `validate_bot_script`, `set_bot_autostart`, `list_bot_messages`, `extract_archive`. The AI is instructed to validate scripts before installing them and to restart the bot afterward.
- `lib/archive.ts` — extracts `.zip` (jszip) and `.tar` / `.tar.gz` / `.tgz` (`tar` package) archives the user has uploaded, returning per-entry path, size, and a text preview.
- `lib/aiTools.ts` uses jszip to package generated `<gs:zip>` blocks. The user-message preamble exposes each attachment's `fileId` so the model can call `extract_archive` against archive uploads.
- `lib/auth.ts` — scrypt password hashing, cookie sessions; `requireUser` + `requireVerified` middleware.

## Frontend
- `pages/landing.tsx` — marketing page (hero, mock chat preview, feature grid, "how it works", CTAs).
- `pages/login.tsx`, `pages/signup.tsx`, `pages/verify.tsx` — auth flow with Turnstile widget and 6-digit OTP. Dev mode also returns the code so it can be shown on the verify screen.
- `pages/app-layout.tsx` — sidebar shell (nav, conversation list with hover-to-delete, account row, owner badge).
- `pages/chat.tsx` — chat surface with attachment chips, drag-and-drop upload, expandable thinking trace, streamed delta rendering, fenced-code rendering, and a generated-files panel.
- `pages/workspace.tsx` — file explorer with full-text search, source filter, inline text editing, download, delete.
- `pages/bots.tsx` — bots list with status pill, modal to add a bot, live log + start/stop/delete in the detail pane (5s polling).
- `components/turnstile.tsx` — explicit-render Cloudflare Turnstile widget.
- `components/CodeBlock.tsx` — copy-to-clipboard fenced code blocks; minimal markdown-ish renderer.
- `lib/streaming.ts` — fetch + SSE parser using `text/event-stream`. Uses `import.meta.env.BASE_URL` for the artifact path prefix.

## Conventions
- Always import generated react-query hooks (e.g. `useGetMe`, `useListBots`) from `@workspace/api-client-react`. When passing `query` options that include `refetchInterval`, also pass `queryKey: getXxxQueryKey()` — orval's options type requires it.
- The shared zod barrel at `lib/api-zod/src/index.ts` only re-exports `./generated/api`; do not add `./generated/zod` exports (none are emitted).
- Wouter v3: `Link` already renders an `<a>`. Never nest a child `<a>`. Use `<Link className=…>` directly, or `<Button asChild><Link …/></Button>` for button-styled links.
- Files API: text content goes in `content`, binary goes base64 in `dataB64`. Both are optional on `FileFull`.
- The `/auth/turnstile-config` endpoint returns the public site key; the secret key stays on the server.

## Secrets
- `SESSION_SECRET` — required for cookie session signing.
- `ANTHROPIC_API_KEY` is provided automatically by the AI integration; do not log or surface it in the UI.

## Known dev defaults
- Cloudflare Turnstile site key falls back to the always-pass test key in development; production should set proper site/secret keys.
- Verify endpoint accepts the dev fallback code `123456` when no real code is on file (helpful for local tests). Production flow uses the issued code only.
