# GScripts AI — Source

Pnpm monorepo (Node 20+, pnpm 9+, PostgreSQL 14+).

## Apps
- `artifacts/api-server` — Express + Pino API (SSE chat, auth, files, bots).
- `artifacts/gscripts-ai` — React + Vite UI (Tailwind v4, TanStack Query, wouter).
- `artifacts/mockup-sandbox` — design preview server (optional).

## Quick start
```bash
pnpm install
pnpm --filter @workspace/db run push           # Drizzle: create tables
ANTHROPIC_API_KEY=...  SESSION_SECRET=$(openssl rand -hex 32)  DATABASE_URL=postgres://...  \
pnpm --filter @workspace/api-server run dev    # API on :8080
pnpm --filter @workspace/gscripts-ai run dev   # Web on :5173
```

## Required environment
- `DATABASE_URL` — Postgres connection string (Neon/Supabase/etc).
- `SESSION_SECRET` — long random string for cookie signing.
- `ANTHROPIC_API_KEY` — model key (the chat backend uses Anthropic Messages API).
- `TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` — optional; defaults fall back to Cloudflare's always-pass test keys in dev.

## Hosting on Vercel
Vercel hosts the React build out of the box from `artifacts/gscripts-ai/dist`. The Express API needs a Node host (Render, Railway, Fly, etc.) because it uses long-lived SSE streams — not a great fit for serverless. Point the web build's `VITE_API_BASE` (or rewrite `/api/*`) to your API URL.

## License
MIT — do whatever you want.
